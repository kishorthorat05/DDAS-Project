# DDAS v3 — Data Download Duplication Alert System

A production-ready full-stack Flask application for detecting and preventing duplicate data downloads, with real-time monitoring, AI analysis, team collaboration, and multi-channel alerts.

---

## 🚀 Features

### Core Detection
- **Exact duplicate detection** via SHA-256 + MD5 checksums
- **Near-duplicate / similarity detection** via fuzzy content fingerprinting
- **Real-time file monitoring** using watchdog filesystem events
- **Dataset versioning** — track changes across uploads of the same dataset

### Analytics & Performance
- **Bandwidth savings tracker** — shows MB/GB saved by blocking duplicates
- **Detection rate metrics** — blocked/total ratio with trend charts
- **Daily upload/duplicate activity charts** (Chart.js)
- **File type distribution donut chart**
- **Top contributor leaderboard**

### Alerts & Notifications
- **In-app alert center** with severity levels (critical/warning/info)
- **📧 Email alerts** via SMTP (Gmail, SendGrid, etc.)
- **💬 WhatsApp alerts** via Twilio API
- **Near-duplicate warnings** with similarity percentage
- **Mark read / resolve / filter** alert workflow

### Team & Access Control
- **Role-based access** — admin / operator / viewer
- **Team creation and member invitation**
- **Per-user notification preferences** (email + WhatsApp opt-in)
- **Audit trail** for all upload and scan events

### AI Assistant (IAS Bot)
- **Google Gemini powered** chat assistant
- **File analysis** — AI insights on uploaded datasets
- **Rule-based fallback** when API key not set
- **Context-aware** — answers about uploaded data

---

## 🛠️ Quick Start

### 1. Install dependencies

```bash
pip install flask flask-cors PyJWT werkzeug python-dotenv requests watchdog
# Optional for WhatsApp:
pip install twilio
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your settings
```

### 3. Run

```bash
python app.py
# Visit http://localhost:5000
```

---

## ⚙️ Configuration (.env)

```env
# Security
SECRET_KEY=your-secret-key-here
JWT_SECRET=your-jwt-secret-here

# Database (SQLite by default)
DATABASE_URL=sqlite:///data/ddas.db

# Directory to monitor for new files
MONITORED_DIR=/home/user/Downloads

# AI (Google Gemini) — optional but recommended
GEMINI_API_KEY=your-gemini-api-key

# Email Alerts (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password
ALERT_EMAIL_FROM=ddas@yourdomain.com

# WhatsApp Alerts (Twilio)
TWILIO_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_TOKEN=your-auth-token
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
```

---

## 📁 Project Structure

```
ddas/
├── app.py                        # Flask app factory + entry point
├── requirements.txt
├── config/
│   └── settings.py               # Environment-driven configuration
├── app/
│   ├── models/
│   │   └── database.py           # SQLite schema + connection helpers
│   ├── services/
│   │   ├── dataset_service.py    # CRUD, versioning, similarity, stats
│   │   ├── monitor_service.py    # Watchdog file monitor + manual scan
│   │   ├── ai_service.py         # Gemini AI + rule-based fallback
│   │   └── notification_service.py # Email (SMTP) + WhatsApp (Twilio)
│   ├── routes/
│   │   └── data_routes.py        # All API blueprints
│   └── utils/
│       └── security.py           # JWT, hashing, sanitization, rate limits
└── static/
    └── index.html                # Full SPA frontend
```

---

## 🗄️ Database Schema

| Table | Purpose |
|-------|---------|
| `users` | Auth, roles, notification prefs |
| `teams` | Team workspaces |
| `team_members` | Team membership with roles |
| `datasets` | File registry with versioning |
| `dataset_versions` | Historical version snapshots |
| `download_history` | Full audit log with bandwidth saved |
| `alerts` | Duplicate/near-duplicate notifications |
| `scan_logs` | File scan results |
| `notification_settings` | Per-user alert preferences |
| `system_settings` | Global config key-value store |

---

## 🔌 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login, get JWT |
| GET | `/api/auth/me` | Current user profile |
| PATCH | `/api/auth/me` | Update profile/notifications |

### Datasets
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/datasets` | List all datasets |
| GET | `/api/datasets/stats` | Dashboard statistics |
| GET | `/api/datasets/search?q=` | Full-text search |
| GET | `/api/datasets/<id>` | Dataset + history + versions |
| GET | `/api/datasets/<id>/similar` | Find similar datasets |

### Upload
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/upload/file` | Upload local file (multipart) |
| POST | `/api/upload/url` | Import from URL |

### Alerts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/alerts` | List alerts (with filters) |
| PATCH | `/api/alerts/<id>/read` | Mark as read |
| POST | `/api/alerts/read-all` | Mark all read |
| POST | `/api/alerts/<id>/resolve` | Resolve alert |
| POST | `/api/notifications/test` | Send test notification |

### Monitor
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/monitor/scan` | Manual directory scan |
| GET | `/api/monitor/status` | Monitor running state |
| POST | `/api/monitor/start` | Start watchdog |
| POST | `/api/monitor/stop` | Stop watchdog (admin) |
| GET | `/api/scan-logs` | Recent scan results |
| GET | `/api/history` | Download history |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/analytics/overview` | Stats + alert breakdown |
| GET | `/api/analytics/bandwidth` | Daily bandwidth savings |
| GET | `/api/analytics/performance` | Detection rate metrics |

### AI
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/ai/chat` | Send chat message |
| POST | `/api/ai/chat/clear` | Clear chat session |
| GET | `/api/ai/status` | Check AI configuration |

### Teams
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/teams/` | List teams |
| POST | `/api/teams/` | Create team |
| GET | `/api/teams/<id>/members` | Team members |
| POST | `/api/teams/<id>/invite` | Invite user |

---

## 📊 Gaps Addressed

| Gap (Original) | Solution in v3 |
|----------------|----------------|
| ❌ No real-time detection | ✅ Watchdog filesystem monitor |
| ❌ Weak logic (name/size only) | ✅ SHA-256 + fuzzy hash similarity |
| ❌ No AI/ML similarity | ✅ Fuzzy fingerprinting + Gemini AI |
| ❌ No user behavior tracking | ✅ Full audit trail + per-user stats |
| ❌ No role-based access | ✅ admin/operator/viewer + teams |
| ❌ No team sharing | ✅ Teams with invitations |
| ❌ No dataset versioning | ✅ Version history with change notes |
| ❌ No bandwidth optimization | ✅ Bandwidth saved tracker |
| ❌ Basic alert system | ✅ Severity levels, email + WhatsApp |
| ❌ No security/access control | ✅ JWT + rate limiting + sanitization |
| ❌ No performance metrics | ✅ Analytics page with charts |
| ❌ No near-duplicate detection | ✅ Fuzzy hash + similarity score |
| ❌ No cloud/URL integration | ✅ Import from any public URL |

---

## 🔐 Security

- JWT Bearer token authentication
- bcrypt/pbkdf2 password hashing
- Rate limiting (per-IP sliding window)
- Input sanitization (XSS, SQL injection prevention)
- Private IP URL blocking (SSRF protection)
- Filename sanitization
- CORS configuration

---

## 📦 Production Deployment

```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"

# Or with Docker
docker build -t ddas .
docker run -p 5000:5000 --env-file .env ddas
```

> **Note:** For multi-worker production, swap the in-memory rate limiter and chat session store for Redis (`flask-limiter` + Redis backend).
