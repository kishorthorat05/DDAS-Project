"""
DDAS — Data Download Duplication Alert System
Production-ready Flask application entry point.
"""
import os
from flask import Flask, send_from_directory
from flask_cors import CORS

from config.settings import get_config
from app.models.database import init_db
from app.routes.auth_routes import auth_bp
from app.routes.data_routes import data_bp
from app.routes.upload_routes import upload_bp
from app.routes.alert_routes import alert_bp
from app.routes.monitor_routes import monitor_bp
from app.routes.ai_routes import ai_bp
from app.routes.analytics_routes import analytics_bp
from app.routes.team_routes import team_bp
from app.services.monitor_service import start_monitor

Config = get_config()


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    app.config.from_object(Config)
    app.config["MAX_CONTENT_LENGTH"] = Config.MAX_CONTENT_LENGTH

    CORS(app, origins=Config.CORS_ORIGINS, supports_credentials=True)

    # Init DB
    Config.init_dirs()
    init_db()

    # Register blueprints
    for bp in [auth_bp, data_bp, upload_bp, alert_bp, monitor_bp, ai_bp, analytics_bp, team_bp]:
        app.register_blueprint(bp)

    # Serve frontend
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_frontend(path):
        if path and os.path.exists(os.path.join("static", path)):
            return send_from_directory("static", path)
        return send_from_directory("static", "index.html")

    # Auto-start monitor in background
    try:
        start_monitor()
    except Exception as e:
        print(f"[Monitor] Could not auto-start: {e}")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
