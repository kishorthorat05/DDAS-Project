"""Database models and schema for DDAS."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator
from config.settings import get_config

Config = get_config()

_db_url = Config.DATABASE_URL
if _db_url.startswith("sqlite:///"):
    DB_PATH = Path(_db_url[len("sqlite:///"):])
else:
    DB_PATH = Path(_db_url)
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def row_to_dict(row):
    return dict(row) if row else None

def rows_to_list(rows):
    return [dict(r) for r in rows]

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    username      TEXT UNIQUE NOT NULL,
    email         TEXT UNIQUE,
    phone         TEXT,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'viewer',
    team_id       TEXT,
    avatar_color  TEXT DEFAULT '#00d4ff',
    notify_email  INTEGER DEFAULT 1,
    notify_whatsapp INTEGER DEFAULT 0,
    is_active     INTEGER NOT NULL DEFAULT 1,
    last_login    TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS teams (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    name        TEXT NOT NULL,
    description TEXT,
    created_by  TEXT REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS team_members (
    id         TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    team_id    TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role       TEXT NOT NULL DEFAULT 'member',
    joined_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    UNIQUE(team_id, user_id)
);

CREATE TABLE IF NOT EXISTS datasets (
    id                  TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    file_hash           TEXT NOT NULL,
    fuzzy_hash          TEXT,
    file_name           TEXT NOT NULL,
    file_size           INTEGER NOT NULL DEFAULT 0,
    file_path           TEXT NOT NULL,
    file_type           TEXT,
    user_name           TEXT NOT NULL DEFAULT 'System',
    user_id             TEXT REFERENCES users(id),
    team_id             TEXT REFERENCES teams(id),
    period              TEXT,
    spatial_domain      TEXT,
    tags                TEXT,
    attributes          TEXT,
    description         TEXT,
    version             INTEGER NOT NULL DEFAULT 1,
    parent_id           TEXT REFERENCES datasets(id),
    is_latest           INTEGER NOT NULL DEFAULT 1,
    source_type         TEXT DEFAULT 'upload',
    source_url          TEXT,
    checksum_md5        TEXT,
    checksum_sha256     TEXT,
    similarity_cluster  TEXT,
    download_count      INTEGER DEFAULT 0,
    last_accessed       TEXT,
    download_timestamp  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_datasets_hash ON datasets(file_hash, version);
CREATE INDEX IF NOT EXISTS idx_datasets_fuzzy   ON datasets(fuzzy_hash);
CREATE INDEX IF NOT EXISTS idx_datasets_user    ON datasets(user_name);
CREATE INDEX IF NOT EXISTS idx_datasets_type    ON datasets(file_type);
CREATE INDEX IF NOT EXISTS idx_datasets_team    ON datasets(team_id);
CREATE INDEX IF NOT EXISTS idx_datasets_created ON datasets(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_datasets_cluster ON datasets(similarity_cluster);

CREATE TABLE IF NOT EXISTS download_history (
    id                TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    dataset_id        TEXT REFERENCES datasets(id) ON DELETE SET NULL,
    user_id           TEXT REFERENCES users(id),
    user_name         TEXT NOT NULL DEFAULT 'System',
    file_name         TEXT,
    file_hash         TEXT,
    attempt_timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    action            TEXT NOT NULL DEFAULT 'upload',
    status            TEXT NOT NULL DEFAULT 'success',
    ip_address        TEXT,
    user_agent        TEXT,
    bandwidth_saved   INTEGER DEFAULT 0,
    notes             TEXT
);

CREATE INDEX IF NOT EXISTS idx_history_dataset   ON download_history(dataset_id);
CREATE INDEX IF NOT EXISTS idx_history_user      ON download_history(user_id);
CREATE INDEX IF NOT EXISTS idx_history_status    ON download_history(status);
CREATE INDEX IF NOT EXISTS idx_history_timestamp ON download_history(attempt_timestamp DESC);

CREATE TABLE IF NOT EXISTS alerts (
    id                  TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    alert_type          TEXT NOT NULL DEFAULT 'duplicate',
    severity            TEXT NOT NULL DEFAULT 'warning',
    title               TEXT NOT NULL,
    message             TEXT NOT NULL,
    file_name           TEXT,
    file_hash           TEXT,
    file_path           TEXT,
    existing_dataset_id TEXT REFERENCES datasets(id) ON DELETE SET NULL,
    triggered_by_user   TEXT,
    similarity_score    REAL,
    email_sent          INTEGER DEFAULT 0,
    whatsapp_sent       INTEGER DEFAULT 0,
    is_read             INTEGER NOT NULL DEFAULT 0,
    resolved            INTEGER NOT NULL DEFAULT 0,
    resolved_at         TEXT,
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_alerts_read    ON alerts(is_read);
CREATE INDEX IF NOT EXISTS idx_alerts_type    ON alerts(alert_type);
CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at DESC);

CREATE TABLE IF NOT EXISTS scan_logs (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    file_path    TEXT NOT NULL,
    file_name    TEXT,
    file_size    INTEGER,
    file_hash    TEXT,
    is_duplicate INTEGER NOT NULL DEFAULT 0,
    similarity_score REAL,
    scanned_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    triggered_by TEXT DEFAULT 'auto',
    error        TEXT
);

CREATE INDEX IF NOT EXISTS idx_scan_logs_scanned ON scan_logs(scanned_at DESC);

CREATE TABLE IF NOT EXISTS notification_settings (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email        TEXT,
    phone        TEXT,
    notify_email INTEGER DEFAULT 1,
    notify_whatsapp INTEGER DEFAULT 0,
    alert_types  TEXT DEFAULT 'duplicate,critical',
    min_severity TEXT DEFAULT 'warning',
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS dataset_versions (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    dataset_id  TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    version     INTEGER NOT NULL,
    file_hash   TEXT NOT NULL,
    file_size   INTEGER,
    file_path   TEXT,
    change_note TEXT,
    changed_by  TEXT,
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS system_settings (
    key   TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

INSERT OR IGNORE INTO system_settings(key, value) VALUES
  ('detection_window_hours', '24'),
  ('max_user_downloads', '10'),
  ('max_ip_downloads', '50'),
  ('similarity_threshold', '0.85'),
  ('enable_fuzzy_detection', '1'),
  ('enable_whatsapp', '0'),
  ('enable_email', '1'),
  ('bandwidth_tracking', '1'),
  ('auto_quarantine', '0'),
  ('retention_days', '90');
"""

def init_db():
    with get_db() as conn:
        conn.executescript(SCHEMA_SQL)
    print(f"[DB] Initialized at {DB_PATH}")
