from app.routes.data_routes import ai_bp
