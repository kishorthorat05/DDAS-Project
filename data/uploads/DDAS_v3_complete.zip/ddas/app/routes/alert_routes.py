from app.routes.data_routes import alert_bp
