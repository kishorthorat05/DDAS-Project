from app.routes.data_routes import analytics_bp
