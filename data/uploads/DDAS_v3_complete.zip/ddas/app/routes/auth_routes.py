"""Auth routes"""
import time
from flask import Blueprint, g, jsonify, request
from app.models.database import get_db, row_to_dict
from app.utils.security import (
    hash_password, verify_password, create_access_token, create_refresh_token,
    jwt_required, require_auth, sanitize_str, rate_limit, decode_token
)

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

def _ok(data=None, **kw):
    p = {"success": True}
    if data is not None: p["data"] = data
    p.update(kw)
    return jsonify(p), 200

def _created(data=None, **kw):
    p = {"success": True}
    if data is not None: p["data"] = data
    p.update(kw)
    return jsonify(p), 201

def _err(msg, code=400, err_code=""):
    return jsonify({"success": False, "error": msg, "code": err_code or "ERROR"}), code

@auth_bp.post("/register")
@rate_limit(max_requests=5, window_seconds=3600)
def register():
    body = request.get_json(silent=True) or {}
    username = sanitize_str(body.get("username",""), 50)
    password = body.get("password","")
    email = sanitize_str(body.get("email",""), 200)
    phone = sanitize_str(body.get("phone",""), 20)
    if not username or len(username) < 3:
        return _err("Username must be at least 3 characters.")
    if len(password) < 6:
        return _err("Password must be at least 6 characters.")
    pw_hash = hash_password(password)
    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (username, email, phone, password_hash) VALUES (?,?,?,?)",
                (username, email or None, phone or None, pw_hash)
            )
            user = row_to_dict(conn.execute(
                "SELECT id,username,email,phone,role,created_at FROM users WHERE username=?", (username,)
            ).fetchone())
    except Exception:
        return _err("Username already exists.", 409, "CONFLICT")
    token = create_access_token({"sub": user["id"], "username": user["username"], "role": user["role"]})
    return _created({"user": user, "access_token": token})

@auth_bp.post("/login")
@rate_limit(max_requests=10, window_seconds=300)
def login():
    body = request.get_json(silent=True) or {}
    username = sanitize_str(body.get("username",""), 50)
    password = body.get("password","")
    with get_db() as conn:
        user = row_to_dict(conn.execute(
            "SELECT * FROM users WHERE username=? AND is_active=1", (username,)
        ).fetchone())
    if not user or not verify_password(password, user["password_hash"]):
        return _err("Invalid credentials.", 401, "INVALID_CREDENTIALS")
    # Update last login
    with get_db() as conn:
        conn.execute("UPDATE users SET last_login=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?", (user["id"],))
    token = create_access_token({"sub": user["id"], "username": user["username"], "role": user["role"]})
    refresh = create_refresh_token(user["id"])
    safe = {k:v for k,v in user.items() if k != "password_hash"}
    return _ok({"user": safe, "access_token": token, "refresh_token": refresh})

@auth_bp.get("/me")
@require_auth
def me():
    uid = g.current_user.get("sub")
    with get_db() as conn:
        user = row_to_dict(conn.execute(
            "SELECT id,username,email,phone,role,avatar_color,notify_email,notify_whatsapp,last_login,created_at FROM users WHERE id=?", (uid,)
        ).fetchone())
    if not user: return _err("User not found.", 404)
    return _ok(user)

@auth_bp.patch("/me")
@require_auth
def update_profile():
    uid = g.current_user.get("sub")
    body = request.get_json(silent=True) or {}
    email = sanitize_str(body.get("email",""), 200)
    phone = sanitize_str(body.get("phone",""), 20)
    notify_email = body.get("notify_email")
    notify_whatsapp = body.get("notify_whatsapp")
    with get_db() as conn:
        if email: conn.execute("UPDATE users SET email=? WHERE id=?", (email, uid))
        if phone: conn.execute("UPDATE users SET phone=? WHERE id=?", (phone, uid))
        if notify_email is not None: conn.execute("UPDATE users SET notify_email=? WHERE id=?", (int(notify_email), uid))
        if notify_whatsapp is not None: conn.execute("UPDATE users SET notify_whatsapp=? WHERE id=?", (int(notify_whatsapp), uid))
        user = row_to_dict(conn.execute("SELECT id,username,email,phone,role,notify_email,notify_whatsapp FROM users WHERE id=?", (uid,)).fetchone())
    return _ok(user)
