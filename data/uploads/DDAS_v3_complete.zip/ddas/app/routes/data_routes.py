"""Data routes"""
import os, uuid
from pathlib import Path
import requests as req_lib
from flask import Blueprint, g, jsonify, request
from app.services.dataset_service import DatasetService, HistoryService, AlertService, ScanLogService, SystemSettingsService
from app.services.notification_service import send_duplicate_alert, send_test_notification
from app.utils.security import (
    jwt_required, require_auth, require_role, rate_limit,
    sanitize_str, sanitize_search_query, sanitize_filename,
    is_allowed_extension, is_safe_url, hash_file, hash_md5, compute_fuzzy_hash
)
from app.models.database import get_db, row_to_dict, rows_to_list
from config.settings import get_config

Config = get_config()

def _ok(data=None, **kw):
    p = {"success": True}
    if data is not None: p["data"] = data
    p.update(kw)
    return jsonify(p), 200

def _created(data=None, **kw):
    p = {"success": True}
    if data is not None: p["data"] = data
    p.update(kw)
    return jsonify(p), 201

def _err(msg, code=400):
    return jsonify({"success": False, "error": msg}), code

def _get_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr or "")

def _get_notification_recipients():
    """Get all users with notifications enabled."""
    emails, phones = [], []
    try:
        with get_db() as conn:
            rows = conn.execute("SELECT email, phone, notify_email, notify_whatsapp FROM users WHERE is_active=1").fetchall()
        for r in rows:
            if r["notify_email"] and r["email"]:
                emails.append(r["email"])
            if r["notify_whatsapp"] and r["phone"]:
                phones.append(r["phone"])
    except Exception:
        pass
    return emails, phones

# ─── Data blueprint ───────────────────────────────────────────────────────────
data_bp = Blueprint("data", __name__, url_prefix="/api")

@data_bp.get("/datasets")
@jwt_required
def get_datasets():
    limit = min(int(request.args.get("limit", 100)), 500)
    offset = int(request.args.get("offset", 0))
    return _ok(DatasetService.get_all(limit, offset))

@data_bp.get("/datasets/stats")
@jwt_required
def dataset_stats():
    return _ok(DatasetService.stats())

@data_bp.get("/datasets/search")
@jwt_required
def search_datasets():
    q = sanitize_search_query(request.args.get("q",""))
    if not q: return _ok(DatasetService.get_all(limit=100))
    return _ok(DatasetService.search(q))

@data_bp.get("/datasets/<dataset_id>")
@jwt_required
def get_dataset(dataset_id):
    ds = DatasetService.get_by_id(dataset_id)
    if not ds: return _err("Dataset not found.", 404)
    history = HistoryService.get_for_dataset(dataset_id)
    versions = DatasetService.get_versions(dataset_id)
    return _ok({"dataset": ds, "history": history, "versions": versions})

@data_bp.get("/datasets/<dataset_id>/similar")
@jwt_required
def get_similar(dataset_id):
    ds = DatasetService.get_by_id(dataset_id)
    if not ds: return _err("Not found.", 404)
    similar = DatasetService.find_similar(ds.get("fuzzy_hash",""), threshold=0.70)
    return _ok(similar)

@data_bp.get("/datasets/<dataset_id>/recommendations")
@jwt_required
def get_recommendations(dataset_id):
    user = g.current_user.get("username","") if g.current_user else ""
    return _ok(DatasetService.get_recommendations(user))

@data_bp.get("/settings")
@jwt_required
def get_settings():
    return _ok(SystemSettingsService.get_all())

@data_bp.post("/settings")
@require_role("admin")
def update_settings():
    body = request.get_json(silent=True) or {}
    for key, val in body.items():
        SystemSettingsService.set(key, val)
    return _ok(SystemSettingsService.get_all())

# ─── Upload blueprint ─────────────────────────────────────────────────────────
upload_bp = Blueprint("upload", __name__, url_prefix="/api")

@upload_bp.post("/upload/file")
@jwt_required
@rate_limit(max_requests=30, window_seconds=3600)
def upload_file():
    if "file" not in request.files:
        return _err("No file provided.")
    file = request.files["file"]
    if not file.filename:
        return _err("Empty filename.")
    filename = sanitize_filename(file.filename)
    if not is_allowed_extension(filename):
        return _err(f"File type not allowed: {Path(filename).suffix}")

    user_name = sanitize_str(request.form.get("user_name","Anonymous"), 100)
    description = sanitize_str(request.form.get("description",""), 500)
    period = sanitize_str(request.form.get("period",""), 100)
    spatial_domain = sanitize_str(request.form.get("spatial_domain",""), 200)
    tags = sanitize_str(request.form.get("tags",""), 200)
    user_id = g.current_user.get("sub") if g.current_user else None

    Config.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
    dest = Config.UPLOAD_FOLDER / filename
    if dest.exists():
        dest = Config.UPLOAD_FOLDER / f"{dest.stem}_{uuid.uuid4().hex[:8]}{dest.suffix}"
    file.save(str(dest))

    file_hash = hash_file(dest)
    fuzzy = compute_fuzzy_hash(dest)
    file_size = dest.stat().st_size
    file_type = dest.suffix.lower()
    checksum_md5 = hash_md5(dest)

    existing = DatasetService.get_by_hash(file_hash)
    if existing:
        HistoryService.log(
            dataset_id=existing["id"], user_name=user_name, user_id=user_id,
            file_name=filename, file_hash=file_hash, action="web_upload",
            status="duplicate_detected", ip_address=_get_ip(),
            user_agent=request.headers.get("User-Agent",""),
            bandwidth_saved=file_size,
        )
        AlertService.create(
            title=f"Duplicate upload: {filename}",
            message=f"Uploaded file matches '{existing['file_name']}' in repository.",
            file_name=filename, file_hash=file_hash, file_path=str(dest),
            existing_dataset_id=existing["id"], triggered_by_user=user_name,
            similarity_score=1.0,
        )
        dest.unlink(missing_ok=True)
        # Send notifications
        emails, phones = _get_notification_recipients()
        send_duplicate_alert(emails, phones, filename, existing["file_name"], user_name, similarity=1.0)
        return _ok({"is_duplicate": True, "existing_file": existing["file_name"], "dataset": existing,
                    "bandwidth_saved": file_size}, message="Duplicate detected.")

    # Check near-duplicates
    similar = DatasetService.find_similar(fuzzy, threshold=0.80) if fuzzy else []
    near_dup = None
    if similar:
        best = similar[0]
        near_dup = {"file_name": best["file_name"], "similarity": best.get("_similarity",0)}
        AlertService.create(
            title=f"Near-duplicate: {filename}",
            message=f"~{best.get('_similarity',0):.0%} similar to '{best['file_name']}'",
            alert_type="near_duplicate", severity="info",
            file_name=filename, file_hash=file_hash, file_path=str(dest),
            existing_dataset_id=best["id"], triggered_by_user=user_name,
            similarity_score=best.get("_similarity",0),
        )

    ds = DatasetService.create(
        file_hash=file_hash, fuzzy_hash=fuzzy, file_name=filename, file_size=file_size,
        file_path=str(dest), file_type=file_type, user_name=user_name, user_id=user_id,
        period=period or None, spatial_domain=spatial_domain or None,
        description=description or None, checksum_md5=checksum_md5, tags=tags or None,
    )
    HistoryService.log(
        dataset_id=ds["id"], user_name=user_name, user_id=user_id,
        file_name=filename, file_hash=file_hash, action="web_upload", status="success",
        ip_address=_get_ip(), user_agent=request.headers.get("User-Agent",""),
    )

    from app.services.ai_service import get_file_insights
    insights = get_file_insights(filename, file_size, file_type, description)
    return _created({"is_duplicate": False, "dataset": ds, "ai_insights": insights, "near_duplicate": near_dup},
                    message="File uploaded successfully.")

@upload_bp.post("/upload/url")
@jwt_required
@rate_limit(max_requests=10, window_seconds=3600)
def upload_from_url():
    body = request.get_json(silent=True) or {}
    url = sanitize_str(body.get("url",""), 2000)
    user_name = sanitize_str(body.get("user_name","Anonymous"), 100)
    description = sanitize_str(body.get("description",""), 500)
    user_id = g.current_user.get("sub") if g.current_user else None

    if not url: return _err("URL is required.")
    if not is_safe_url(url): return _err("Invalid or unsafe URL.", 400)

    try:
        resp = req_lib.get(url, timeout=30, stream=True, headers={"User-Agent": "DDAS/3.0"})
        resp.raise_for_status()
    except req_lib.RequestException as exc:
        return _err(f"Failed to download: {exc}", 400)

    from urllib.parse import urlparse
    url_path = urlparse(url).path
    filename = sanitize_filename(os.path.basename(url_path) or f"download_{uuid.uuid4().hex[:8]}")
    if not is_allowed_extension(filename):
        filename += ".bin"

    Config.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
    dest = Config.UPLOAD_FOLDER / filename
    if dest.exists():
        dest = Config.UPLOAD_FOLDER / f"{dest.stem}_{uuid.uuid4().hex[:8]}{dest.suffix}"

    with open(dest, "wb") as fh:
        for chunk in resp.iter_content(chunk_size=65536):
            fh.write(chunk)

    file_hash = hash_file(dest)
    fuzzy = compute_fuzzy_hash(dest)
    file_size = dest.stat().st_size
    file_type = dest.suffix.lower()

    existing = DatasetService.get_by_hash(file_hash)
    if existing:
        dest.unlink(missing_ok=True)
        emails, phones = _get_notification_recipients()
        send_duplicate_alert(emails, phones, filename, existing["file_name"], user_name, similarity=1.0)
        return _ok({"is_duplicate": True, "existing_file": existing["file_name"], "dataset": existing},
                   message="Duplicate detected.")

    ds = DatasetService.create(
        file_hash=file_hash, fuzzy_hash=fuzzy, file_name=filename, file_size=file_size,
        file_path=str(dest), file_type=file_type, user_name=user_name, user_id=user_id,
        description=description or None, source_type="url", source_url=url,
    )
    from app.services.ai_service import get_file_insights
    insights = get_file_insights(filename, file_size, file_type, description)
    return _created({"is_duplicate": False, "dataset": ds, "ai_insights": insights},
                    message="File downloaded and registered.")

# ─── Alert blueprint ──────────────────────────────────────────────────────────
alert_bp = Blueprint("alerts", __name__, url_prefix="/api")

@alert_bp.get("/alerts")
@jwt_required
def get_alerts():
    unread_only = request.args.get("unread") == "1"
    limit = min(int(request.args.get("limit", 100)), 500)
    severity = request.args.get("severity")
    alerts = AlertService.get_all(unread_only=unread_only, limit=limit, severity=severity)
    count = AlertService.unread_count()
    return _ok({"alerts": alerts, "unread_count": count})

@alert_bp.patch("/alerts/<alert_id>/read")
@jwt_required
def mark_alert_read(alert_id):
    AlertService.mark_read(alert_id)
    return _ok(message="Marked as read.")

@alert_bp.post("/alerts/read-all")
@jwt_required
def mark_all_read():
    AlertService.mark_all_read()
    return _ok(message="All marked as read.")

@alert_bp.post("/alerts/<alert_id>/resolve")
@jwt_required
def resolve_alert(alert_id):
    AlertService.resolve(alert_id)
    return _ok(message="Alert resolved.")

@alert_bp.post("/notifications/test")
@jwt_required
def test_notification():
    body = request.get_json(silent=True) or {}
    email = body.get("email")
    phone = body.get("phone")
    result = send_test_notification(email, phone)
    return _ok(result, message="Test notification queued.")

# ─── Monitor blueprint ────────────────────────────────────────────────────────
monitor_bp = Blueprint("monitor", __name__, url_prefix="/api")

@monitor_bp.post("/monitor/scan")
@jwt_required
@rate_limit(max_requests=10, window_seconds=60)
def trigger_scan():
    from app.services.monitor_service import manual_scan
    body = request.get_json(silent=True, force=True) or {}
    directory = sanitize_str(body.get("directory",""), 500) if request.data else ""
    result = manual_scan(directory or None)
    return _ok(result)

@monitor_bp.get("/monitor/status")
@jwt_required
def get_monitor_status():
    from app.services.monitor_service import monitor_status
    return _ok(monitor_status())

@monitor_bp.post("/monitor/start")
@require_auth
def start_monitor_route():
    from app.services.monitor_service import start_monitor
    started = start_monitor()
    return _ok({"started": started})

@monitor_bp.post("/monitor/stop")
@require_role("admin")
def stop_monitor_route():
    from app.services.monitor_service import stop_monitor
    stop_monitor()
    return _ok({"stopped": True})

@monitor_bp.get("/scan-logs")
@jwt_required
def get_scan_logs():
    limit = min(int(request.args.get("limit", 100)), 500)
    return _ok(ScanLogService.get_recent(limit))

@monitor_bp.get("/history")
@jwt_required
def get_history():
    limit = min(int(request.args.get("limit", 100)), 500)
    return _ok(HistoryService.get_recent(limit))

# ─── AI blueprint ─────────────────────────────────────────────────────────────
ai_bp = Blueprint("ai", __name__, url_prefix="/api/ai")
_chat_sessions: dict = {}
_MAX_HISTORY = 20

@ai_bp.post("/chat")
@jwt_required
@rate_limit(max_requests=60, window_seconds=3600)
def chat_endpoint():
    from app.services.ai_service import chat, is_api_configured
    body = request.get_json(silent=True) or {}
    message = sanitize_str(body.get("message",""), 2000)
    session_id = sanitize_str(body.get("session_id","default"), 64)
    context = sanitize_str(body.get("context",""), 1000)
    if not message: return _err("message is required.")
    history = _chat_sessions.get(session_id, [])
    reply = chat(message, history, context)
    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": reply})
    _chat_sessions[session_id] = history[-_MAX_HISTORY:]
    return _ok({"reply": reply, "session_id": session_id})

@ai_bp.post("/chat/clear")
@jwt_required
def clear_chat():
    body = request.get_json(silent=True) or {}
    session_id = sanitize_str(body.get("session_id","default"), 64)
    _chat_sessions.pop(session_id, None)
    return _ok(message="Cleared.")

@ai_bp.get("/status")
def ai_status():
    from app.services.ai_service import is_api_configured
    return _ok({"api_configured": is_api_configured(), "model": Config.GEMINI_MODEL, "provider": "Google Gemini"})

# ─── Analytics blueprint ──────────────────────────────────────────────────────
analytics_bp = Blueprint("analytics", __name__, url_prefix="/api/analytics")

@analytics_bp.get("/overview")
@jwt_required
def overview():
    stats = DatasetService.stats()
    alert_stats = AlertService.stats_by_severity()
    return _ok({"stats": stats, "alert_severity": alert_stats})

@analytics_bp.get("/bandwidth")
@jwt_required
def bandwidth():
    with get_db() as conn:
        rows = conn.execute("""
            SELECT date(attempt_timestamp) as day, SUM(bandwidth_saved) as saved, COUNT(*) as blocked
            FROM download_history WHERE status='duplicate_detected'
            AND attempt_timestamp >= date('now', '-30 days')
            GROUP BY day ORDER BY day""").fetchall()
    return _ok(rows_to_list(rows))

@analytics_bp.get("/performance")
@jwt_required
def performance():
    with get_db() as conn:
        total_uploads = conn.execute("SELECT COUNT(*) FROM download_history").fetchone()[0]
        total_blocked = conn.execute("SELECT COUNT(*) FROM download_history WHERE status='duplicate_detected'").fetchone()[0]
        avg_file_size = conn.execute("SELECT AVG(file_size) FROM datasets WHERE is_latest=1").fetchone()[0] or 0
        detection_rate = (total_blocked / total_uploads * 100) if total_uploads > 0 else 0
        unique_hashes = conn.execute("SELECT COUNT(DISTINCT file_hash) FROM datasets").fetchone()[0]
    return _ok({
        "total_uploads": total_uploads,
        "total_blocked": total_blocked,
        "detection_rate": round(detection_rate, 2),
        "avg_file_size_bytes": int(avg_file_size),
        "unique_hashes": unique_hashes,
    })

# ─── Team blueprint ───────────────────────────────────────────────────────────
team_bp = Blueprint("team", __name__, url_prefix="/api/teams")

@team_bp.get("/")
@jwt_required
def get_teams():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM teams ORDER BY created_at DESC").fetchall()
    return _ok(rows_to_list(rows))

@team_bp.post("/")
@require_auth
def create_team():
    body = request.get_json(silent=True) or {}
    name = sanitize_str(body.get("name",""), 100)
    description = sanitize_str(body.get("description",""), 500)
    if not name: return _err("Team name required.")
    uid = g.current_user.get("sub")
    with get_db() as conn:
        conn.execute("INSERT INTO teams(name,description,created_by) VALUES(?,?,?)", (name,description,uid))
        team = row_to_dict(conn.execute("SELECT * FROM teams ORDER BY created_at DESC LIMIT 1").fetchone())
        conn.execute("INSERT INTO team_members(team_id,user_id,role) VALUES(?,?,'admin')", (team["id"],uid))
    return _created(team)

@team_bp.get("/<team_id>/members")
@jwt_required
def get_members(team_id):
    with get_db() as conn:
        rows = conn.execute("""
            SELECT u.id,u.username,u.email,u.role,tm.role as team_role,tm.joined_at
            FROM team_members tm JOIN users u ON tm.user_id=u.id
            WHERE tm.team_id=?""", (team_id,)).fetchall()
    return _ok(rows_to_list(rows))

@team_bp.post("/<team_id>/invite")
@require_auth
def invite_member(team_id):
    body = request.get_json(silent=True) or {}
    username = sanitize_str(body.get("username",""), 50)
    if not username: return _err("Username required.")
    with get_db() as conn:
        user = row_to_dict(conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone())
        if not user: return _err(f"User '{username}' not found.", 404)
        try:
            conn.execute("INSERT INTO team_members(team_id,user_id) VALUES(?,?)", (team_id, user["id"]))
        except Exception:
            return _err("User already in team.", 409)
    return _ok(message=f"'{username}' added to team.")
