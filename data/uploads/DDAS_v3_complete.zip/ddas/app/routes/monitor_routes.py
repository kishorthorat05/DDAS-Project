from app.routes.data_routes import monitor_bp
