from app.routes.data_routes import (
    upload_bp, alert_bp, monitor_bp, ai_bp, analytics_bp, team_bp
)
