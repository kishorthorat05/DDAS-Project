"""AI service powered by Google Gemini."""
import os, re, json
from pathlib import Path
from typing import Any
import requests
from config.settings import get_config

Config = get_config()

def _get_api_key():
    return os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or Config.GEMINI_API_KEY or ""

def is_api_configured():
    key = _get_api_key()
    return bool(key) and len(key) >= 20

_MODELS = ["gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash"]

def _call_gemini(system, messages, max_tokens=None):
    key = _get_api_key()
    if not key:
        raise RuntimeError("No API key")
    contents = []
    for m in messages:
        role = "model" if m["role"] == "assistant" else "user"
        contents.append({"role": role, "parts": [{"text": m["content"]}]})
    if not contents:
        contents = [{"role": "user", "parts": [{"text": "Hello"}]}]
    for model in _MODELS:
        try:
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                params={"key": key},
                json={
                    "systemInstruction": {"parts": [{"text": system}]},
                    "contents": contents,
                    "generationConfig": {"maxOutputTokens": max_tokens or Config.AI_MAX_TOKENS, "temperature": 0.4},
                },
                timeout=45,
            )
            if r.status_code == 200:
                payload = r.json()
                parts = []
                for cand in payload.get("candidates", []):
                    for part in cand.get("content", {}).get("parts", []):
                        if part.get("text"):
                            parts.append(part["text"])
                text = "\n".join(parts).strip()
                if text:
                    return text
        except Exception:
            continue
    raise RuntimeError("All Gemini models failed")

_CHAT_SYSTEM = """You are IAS Bot, an AI assistant for DDAS (Data Download Duplication Alert System).
Help users with: file uploads, duplicate detection (SHA-256 hashing), repository management, alerts, analytics, team collaboration, dataset versioning, and bandwidth optimization.
Be concise, use markdown, keep replies under 350 words unless detail is clearly needed.
Do not answer unrelated questions (sports, entertainment, general trivia)."""

_INSIGHT_SYSTEM = """You are a data analyst. Given uploaded file metadata, produce a concise structured analysis:
1. What the file likely contains
2. Recommended processing tools
3. Key analysis steps
4. Best practices
5. Concrete next step
Use markdown. Under 300 words."""

def get_file_insights(file_name, file_size, file_type, description=""):
    if not is_api_configured():
        return _rule_insights(file_name, file_size, file_type, description)
    size_mb = file_size / (1024*1024)
    prompt = f"File: **{file_name}**\nSize: {size_mb:.2f} MB\nType: `{file_type}`\nDescription: {description or 'Not provided'}\n\nAnalyze this file."
    try:
        return _call_gemini(_INSIGHT_SYSTEM, [{"role": "user", "content": prompt}], max_tokens=400)
    except Exception as e:
        return _rule_insights(file_name, file_size, file_type, description)

def chat(message, history, context=""):
    if not is_api_configured():
        return _rule_chat(message)
    system = _CHAT_SYSTEM
    if context:
        system += f"\n\nCurrent upload context:\n{context}"
    messages = [{"role": m["role"], "content": m["content"]} for m in history[-16:] if m.get("content")]
    messages.append({"role": "user", "content": message})
    try:
        return _call_gemini(system, messages, max_tokens=512)
    except Exception:
        return _rule_chat(message)

def _rule_insights(name, size, ftype, desc):
    size_mb = size / (1024*1024)
    ext = ftype.lstrip(".").lower()
    type_map = {
        "csv": ("📊 Tabular data", "Pandas, DuckDB, Excel", "pd.read_csv(), check dtypes, handle nulls"),
        "json": ("🔗 Structured nested data", "Python json, Pandas", "json.load(), pd.json_normalize()"),
        "xlsx": ("📈 Excel workbook", "openpyxl, Pandas", "pd.ExcelFile() to inspect sheets"),
        "pdf": ("📄 Document", "pdfplumber, PyMuPDF", "Extract text with pdfplumber"),
        "geojson": ("🗺️ Spatial data", "GeoPandas, QGIS", "geopandas.read_file()"),
        "nc": ("🌍 NetCDF scientific data", "xarray, netCDF4", "xr.open_dataset()"),
    }
    cat, tools, steps = type_map.get(ext, (f"📂 {ftype} file", "File-type tools", "Inspect with file command"))
    return (f"## {cat}\n\n**File:** `{name}` | **Size:** {size_mb:.2f} MB\n\n"
            f"**Tools:** {tools}\n\n**Steps:** {steps}\n\n"
            f"{'**Description:** ' + desc + chr(10)*2 if desc else ''}"
            f"**Best practices:** Verify integrity, check for missing values, keep original backup.\n\n"
            f"*Configure GEMINI_API_KEY for full AI analysis.*")

def _rule_chat(message):
    m = message.lower()
    if any(w in m for w in ("hello","hi","hey")):
        return "👋 Hello! I'm IAS Bot. Ask me about DDAS — uploads, duplicates, alerts, analytics, or team features."
    if "duplicate" in m or "hash" in m:
        return "**Duplicate Detection:** DDAS uses SHA-256 hashing for exact matches, plus fuzzy hashing for near-duplicates (~similarity scoring). Every uploaded file gets fingerprinted and compared against the repository."
    if "upload" in m:
        return "**Upload:** Use the Upload tab → drop a file or paste a URL → add metadata → click Upload. The system auto-detects duplicates and generates AI insights."
    if "version" in m:
        return "**Versioning:** DDAS tracks dataset versions. Upload a new version of an existing file to create a version history with change notes."
    if "team" in m:
        return "**Teams:** Create a team, invite members, and share datasets with your team. Role-based access (admin/operator/viewer) controls permissions."
    if "bandwidth" in m:
        return "**Bandwidth Optimization:** Every blocked duplicate saves bandwidth. The dashboard shows total bandwidth saved. Delta detection prevents redundant downloads."
    return "I can help with uploads, duplicate detection, alerts, analytics, teams, and versioning. What would you like to know? (Set GEMINI_API_KEY for full AI responses)"
