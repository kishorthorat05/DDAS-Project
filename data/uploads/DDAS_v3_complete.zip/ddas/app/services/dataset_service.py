"""DatasetService — all DB operations for datasets, history, alerts, scan_logs."""
import json
from typing import Any
from app.models.database import get_db, row_to_dict, rows_to_list


class DatasetService:
    @staticmethod
    def get_all(limit=200, offset=0):
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM datasets WHERE is_latest=1 ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset)
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def get_by_id(dataset_id):
        with get_db() as conn:
            row = conn.execute("SELECT * FROM datasets WHERE id=?", (dataset_id,)).fetchone()
        return row_to_dict(row)

    @staticmethod
    def get_by_hash(file_hash):
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM datasets WHERE file_hash=? AND is_latest=1", (file_hash,)
            ).fetchone()
        return row_to_dict(row)

    @staticmethod
    def find_similar(fuzzy_hash: str, threshold: float = 0.75, limit: int = 5):
        """Find datasets with similar fuzzy hash."""
        if not fuzzy_hash:
            return []
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM datasets WHERE fuzzy_hash IS NOT NULL AND is_latest=1 LIMIT 500"
            ).fetchall()
        results = []
        for row in rows_to_list(rows):
            fh = row.get("fuzzy_hash", "")
            if fh and fh != fuzzy_hash:
                # Simple char-level similarity
                min_len = min(len(fh), len(fuzzy_hash))
                if min_len > 0:
                    score = sum(a == b for a, b in zip(fh[:min_len], fuzzy_hash[:min_len])) / min_len
                    if score >= threshold:
                        row["_similarity"] = score
                        results.append(row)
        results.sort(key=lambda x: x["_similarity"], reverse=True)
        return results[:limit]

    @staticmethod
    def create(file_hash, file_name, file_size, file_path, file_type="",
               user_name="System", user_id=None, team_id=None, period=None,
               spatial_domain=None, attributes=None, description=None,
               source_type="upload", source_url=None, fuzzy_hash=None,
               checksum_md5=None, tags=None):
        attrs_json = json.dumps(attributes) if attributes else None
        with get_db() as conn:
            conn.execute("""
                INSERT INTO datasets
                (file_hash,fuzzy_hash,file_name,file_size,file_path,file_type,
                 user_name,user_id,team_id,period,spatial_domain,tags,attributes,
                 description,source_type,source_url,checksum_md5,checksum_sha256)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (file_hash,fuzzy_hash,file_name,file_size,file_path,file_type,
                 user_name,user_id,team_id,period,spatial_domain,tags,attrs_json,
                 description,source_type,source_url,checksum_md5,file_hash)
            )
            row = conn.execute(
                "SELECT * FROM datasets WHERE file_hash=? AND is_latest=1", (file_hash,)
            ).fetchone()
        return row_to_dict(row)

    @staticmethod
    def create_version(existing_id, file_hash, file_name, file_size, file_path,
                       file_type="", user_name="System", change_note="", **kwargs):
        """Create a new version of an existing dataset."""
        with get_db() as conn:
            existing = row_to_dict(conn.execute("SELECT * FROM datasets WHERE id=?", (existing_id,)).fetchone())
            if not existing:
                return None
            new_version = existing.get("version", 1) + 1
            # Mark old as not latest
            conn.execute("UPDATE datasets SET is_latest=0 WHERE id=?", (existing_id,))
            # Log version history
            conn.execute("""
                INSERT INTO dataset_versions(dataset_id, version, file_hash, file_size, file_path, change_note, changed_by)
                VALUES (?,?,?,?,?,?,?)""",
                (existing_id, existing.get("version",1), existing["file_hash"],
                 existing["file_size"], existing["file_path"], "Previous version", user_name)
            )
            # Create new
            conn.execute("""
                INSERT INTO datasets
                (file_hash,file_name,file_size,file_path,file_type,user_name,
                 period,spatial_domain,description,version,parent_id,is_latest,source_type)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?)""",
                (file_hash,file_name,file_size,file_path,file_type,user_name,
                 existing.get("period"),existing.get("spatial_domain"),
                 existing.get("description"),new_version,existing_id,
                 existing.get("source_type","upload"))
            )
            row = conn.execute(
                "SELECT * FROM datasets WHERE file_hash=? AND is_latest=1", (file_hash,)
            ).fetchone()
        return row_to_dict(row)

    @staticmethod
    def get_versions(dataset_id):
        with get_db() as conn:
            # Get root
            root = row_to_dict(conn.execute(
                "SELECT * FROM datasets WHERE id=? OR parent_id=?", (dataset_id, dataset_id)
            ).fetchone())
            rows = conn.execute(
                "SELECT * FROM dataset_versions WHERE dataset_id=? ORDER BY version DESC", (dataset_id,)
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def increment_download(dataset_id):
        with get_db() as conn:
            conn.execute("""
                UPDATE datasets SET download_count=COALESCE(download_count,0)+1,
                last_accessed=strftime('%Y-%m-%dT%H:%M:%fZ','now')
                WHERE id=?""", (dataset_id,))

    @staticmethod
    def search(query, limit=100):
        pattern = f"%{query}%"
        with get_db() as conn:
            rows = conn.execute("""
                SELECT * FROM datasets
                WHERE is_latest=1 AND (
                    file_name LIKE ? OR spatial_domain LIKE ? OR period LIKE ?
                    OR description LIKE ? OR file_type LIKE ? OR tags LIKE ?
                    OR user_name LIKE ?
                )
                ORDER BY created_at DESC LIMIT ?""",
                (pattern,)*7 + (limit,)
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def stats():
        with get_db() as conn:
            total = conn.execute("SELECT COUNT(*) FROM datasets WHERE is_latest=1").fetchone()[0]
            total_size = conn.execute("SELECT COALESCE(SUM(file_size),0) FROM datasets WHERE is_latest=1").fetchone()[0]
            dup_count = conn.execute("SELECT COUNT(*) FROM download_history WHERE status='duplicate_detected'").fetchone()[0]
            bandwidth_saved = conn.execute("SELECT COALESCE(SUM(bandwidth_saved),0) FROM download_history").fetchone()[0]
            alerts_unread = conn.execute("SELECT COUNT(*) FROM alerts WHERE is_read=0").fetchone()[0]
            unique_users = conn.execute("SELECT COUNT(DISTINCT user_name) FROM datasets WHERE is_latest=1").fetchone()[0]
            file_types = conn.execute("""
                SELECT file_type, COUNT(*) as cnt FROM datasets
                WHERE file_type IS NOT NULL AND is_latest=1
                GROUP BY file_type ORDER BY cnt DESC LIMIT 8""").fetchall()
            daily_uploads = conn.execute("""
                SELECT date(created_at) as day, COUNT(*) as cnt
                FROM datasets WHERE is_latest=1
                AND created_at >= date('now', '-30 days')
                GROUP BY day ORDER BY day""").fetchall()
            daily_dupes = conn.execute("""
                SELECT date(attempt_timestamp) as day, COUNT(*) as cnt
                FROM download_history WHERE status='duplicate_detected'
                AND attempt_timestamp >= date('now', '-30 days')
                GROUP BY day ORDER BY day""").fetchall()
            top_users = conn.execute("""
                SELECT user_name, COUNT(*) as uploads FROM datasets
                WHERE is_latest=1 GROUP BY user_name ORDER BY uploads DESC LIMIT 5""").fetchall()
        return {
            "total_datasets": total,
            "total_size_bytes": total_size,
            "duplicate_prevention_count": dup_count,
            "bandwidth_saved_bytes": bandwidth_saved,
            "alerts_unread": alerts_unread,
            "unique_users": unique_users,
            "file_type_breakdown": rows_to_list(file_types),
            "daily_uploads": rows_to_list(daily_uploads),
            "daily_duplicates": rows_to_list(daily_dupes),
            "top_users": rows_to_list(top_users),
        }

    @staticmethod
    def get_recommendations(user_name: str, limit=5):
        """Recommend datasets based on user's upload history."""
        with get_db() as conn:
            user_types = conn.execute("""
                SELECT file_type FROM datasets WHERE user_name=? AND is_latest=1
                GROUP BY file_type ORDER BY COUNT(*) DESC LIMIT 3""",
                (user_name,)
            ).fetchall()
            if not user_types:
                rows = conn.execute(
                    "SELECT * FROM datasets WHERE is_latest=1 ORDER BY download_count DESC LIMIT ?", (limit,)
                ).fetchall()
            else:
                types = [r[0] for r in user_types]
                placeholders = ",".join("?" * len(types))
                rows = conn.execute(f"""
                    SELECT * FROM datasets WHERE is_latest=1
                    AND file_type IN ({placeholders})
                    AND user_name != ?
                    ORDER BY download_count DESC LIMIT ?""",
                    types + [user_name, limit]
                ).fetchall()
        return rows_to_list(rows)


class HistoryService:
    @staticmethod
    def log(dataset_id=None, user_name="System", user_id=None, file_name="",
            file_hash="", action="upload", status="success", ip_address="",
            user_agent="", bandwidth_saved=0, notes=""):
        with get_db() as conn:
            conn.execute("""
                INSERT INTO download_history
                (dataset_id,user_id,user_name,file_name,file_hash,action,status,
                 ip_address,user_agent,bandwidth_saved,notes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (dataset_id,user_id,user_name,file_name,file_hash,action,status,
                 ip_address,user_agent,bandwidth_saved,notes)
            )

    @staticmethod
    def get_for_dataset(dataset_id, limit=50):
        with get_db() as conn:
            rows = conn.execute("""
                SELECT * FROM download_history WHERE dataset_id=?
                ORDER BY attempt_timestamp DESC LIMIT ?""", (dataset_id, limit)
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def get_recent(limit=100):
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM download_history ORDER BY attempt_timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
        return rows_to_list(rows)


class AlertService:
    @staticmethod
    def create(title, message, alert_type="duplicate", severity="warning",
               file_name="", file_hash="", file_path="", existing_dataset_id=None,
               triggered_by_user=None, similarity_score=None):
        with get_db() as conn:
            conn.execute("""
                INSERT INTO alerts
                (alert_type,severity,title,message,file_name,file_hash,file_path,
                 existing_dataset_id,triggered_by_user,similarity_score)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (alert_type,severity,title,message,file_name,file_hash,file_path,
                 existing_dataset_id,triggered_by_user,similarity_score)
            )
            row = conn.execute("SELECT * FROM alerts ORDER BY created_at DESC LIMIT 1").fetchone()
        return row_to_dict(row)

    @staticmethod
    def get_all(unread_only=False, limit=100, severity=None):
        sql = "SELECT * FROM alerts"
        params = []
        where = []
        if unread_only:
            where.append("is_read=0")
        if severity:
            where.append("severity=?")
            params.append(severity)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with get_db() as conn:
            rows = conn.execute(sql, params).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def mark_read(alert_id):
        with get_db() as conn:
            conn.execute("UPDATE alerts SET is_read=1 WHERE id=?", (alert_id,))

    @staticmethod
    def mark_all_read():
        with get_db() as conn:
            conn.execute("UPDATE alerts SET is_read=1")

    @staticmethod
    def resolve(alert_id):
        with get_db() as conn:
            conn.execute("""
                UPDATE alerts SET resolved=1, resolved_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')
                WHERE id=?""", (alert_id,))

    @staticmethod
    def unread_count():
        with get_db() as conn:
            return conn.execute("SELECT COUNT(*) FROM alerts WHERE is_read=0").fetchone()[0]

    @staticmethod
    def stats_by_severity():
        with get_db() as conn:
            rows = conn.execute("""
                SELECT severity, COUNT(*) as cnt FROM alerts
                GROUP BY severity""").fetchall()
        return rows_to_list(rows)


class ScanLogService:
    @staticmethod
    def log(file_path, file_name="", file_size=0, file_hash="",
            is_duplicate=False, error="", similarity_score=None, triggered_by="auto"):
        with get_db() as conn:
            conn.execute("""
                INSERT INTO scan_logs
                (file_path,file_name,file_size,file_hash,is_duplicate,error,similarity_score,triggered_by)
                VALUES (?,?,?,?,?,?,?,?)""",
                (file_path,file_name,file_size,file_hash,1 if is_duplicate else 0,
                 error or None, similarity_score, triggered_by)
            )

    @staticmethod
    def get_recent(limit=100):
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM scan_logs ORDER BY scanned_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return rows_to_list(rows)


class SystemSettingsService:
    @staticmethod
    def get(key, default=None):
        with get_db() as conn:
            row = conn.execute("SELECT value FROM system_settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    @staticmethod
    def set(key, value):
        with get_db() as conn:
            conn.execute("""
                INSERT INTO system_settings(key, value) VALUES(?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value,
                updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')""",
                (key, str(value))
            )

    @staticmethod
    def get_all():
        with get_db() as conn:
            rows = conn.execute("SELECT key, value FROM system_settings").fetchall()
        return {r["key"]: r["value"] for r in rows}
