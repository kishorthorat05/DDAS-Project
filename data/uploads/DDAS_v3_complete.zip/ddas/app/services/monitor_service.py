"""FileMonitor — watchdog-based directory watcher."""
import os
import threading
from pathlib import Path

from app.services.dataset_service import AlertService, DatasetService, HistoryService, ScanLogService
from app.utils.security import hash_file, compute_fuzzy_hash
from config.settings import get_config

Config = get_config()

try:
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    FileSystemEventHandler = object
    class Observer:
        def __init__(self): pass
        def schedule(self, *a, **kw): pass
        def start(self): pass
        def stop(self): pass
        def join(self, timeout=None): pass
        def is_alive(self): return False


class _DDASEventHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            _process_file(event.src_path, triggered_by="watchdog")

    def on_moved(self, event):
        if not event.is_directory:
            _process_file(event.dest_path, triggered_by="watchdog_move")


def _process_file(file_path: str, triggered_by: str = "manual") -> dict:
    path = Path(file_path)
    file_name = path.name
    result = {"file_path": file_path, "file_name": file_name, "is_duplicate": False, "error": None, "triggered_by": triggered_by}

    try:
        if file_name.startswith(".") or file_name.endswith((".tmp", ".part", ".crdownload")):
            return result

        file_hash = hash_file(file_path)
        fuzzy = compute_fuzzy_hash(file_path)
        file_size = path.stat().st_size
        file_type = path.suffix.lower()

        existing = DatasetService.get_by_hash(file_hash)
        similarity_score = None

        if existing:
            result["is_duplicate"] = True
            AlertService.create(
                title=f"Duplicate detected: {file_name}",
                message=f"File '{file_name}' is an exact duplicate of '{existing['file_name']}' (added by {existing['user_name']})",
                alert_type="duplicate", severity="warning",
                file_name=file_name, file_hash=file_hash, file_path=file_path,
                existing_dataset_id=existing["id"], similarity_score=1.0,
            )
            HistoryService.log(
                dataset_id=existing["id"], user_name="System", file_name=file_name,
                file_hash=file_hash, action="auto_scan", status="duplicate_detected",
                bandwidth_saved=file_size, notes=f"Detected by {triggered_by}",
            )
        else:
            # Check fuzzy similarity
            similar = DatasetService.find_similar(fuzzy, threshold=0.80) if fuzzy else []
            if similar:
                best = similar[0]
                similarity_score = best.get("_similarity", 0)
                AlertService.create(
                    title=f"Near-duplicate detected: {file_name}",
                    message=f"File '{file_name}' is ~{similarity_score:.0%} similar to '{best['file_name']}'",
                    alert_type="near_duplicate", severity="info",
                    file_name=file_name, file_hash=file_hash, file_path=file_path,
                    existing_dataset_id=best["id"], similarity_score=similarity_score,
                )
            DatasetService.create(
                file_hash=file_hash, fuzzy_hash=fuzzy, file_name=file_name,
                file_size=file_size, file_path=file_path, file_type=file_type,
            )

        ScanLogService.log(
            file_path=file_path, file_name=file_name, file_size=file_size,
            file_hash=file_hash, is_duplicate=result["is_duplicate"],
            similarity_score=similarity_score, triggered_by=triggered_by,
        )
    except PermissionError:
        result["error"] = "Permission denied"
    except FileNotFoundError:
        result["error"] = "File not found"
    except Exception as exc:
        result["error"] = str(exc)
    return result


def manual_scan(directory=None) -> dict:
    scan_dir = directory or Config.MONITORED_DIR
    results = {"scanned": 0, "duplicates": 0, "near_duplicates": 0, "errors": 0, "new": 0, "directory": scan_dir}
    if not os.path.isdir(scan_dir):
        results["error"] = f"Directory not found: {scan_dir}"
        return results
    for entry in os.scandir(scan_dir):
        if entry.is_file():
            r = _process_file(entry.path, triggered_by="manual_scan")
            results["scanned"] += 1
            if r.get("is_duplicate"):
                results["duplicates"] += 1
            elif r.get("error"):
                results["errors"] += 1
            else:
                results["new"] += 1
    return results


_observer = None
_observer_lock = threading.Lock()


def start_monitor(directory=None) -> bool:
    global _observer
    with _observer_lock:
        if _observer and _observer.is_alive():
            return False
        watch_dir = directory or Config.MONITORED_DIR
        os.makedirs(watch_dir, exist_ok=True)
        if WATCHDOG_AVAILABLE:
            _observer = Observer()
            _observer.schedule(_DDASEventHandler(), watch_dir, recursive=False)
            _observer.start()
            print(f"[Monitor] Started watching: {watch_dir}")
        else:
            print("[Monitor] watchdog not installed, monitoring disabled")
        return True


def stop_monitor():
    global _observer
    with _observer_lock:
        if _observer and _observer.is_alive():
            _observer.stop()
            _observer.join(timeout=5)
            _observer = None
            print("[Monitor] Stopped.")


def monitor_status() -> dict:
    return {
        "running": bool(_observer and _observer.is_alive()),
        "directory": Config.MONITORED_DIR,
        "watchdog_available": WATCHDOG_AVAILABLE,
    }
