"""
Notification service — Email (SMTP) and WhatsApp (Twilio) alerts.
"""
import smtplib
import threading
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

from config.settings import get_config

Config = get_config()


def _send_email_async(to_list, subject, html_body):
    def _send():
        if not Config.SMTP_USER or not Config.SMTP_PASS:
            print(f"[Email] SMTP not configured. Would send to {to_list}: {subject}")
            return
        try:
            msg = MIMEMultipart("alternative")
            msg["From"] = Config.ALERT_EMAIL_FROM or Config.SMTP_USER
            msg["To"] = ", ".join(to_list)
            msg["Subject"] = subject
            msg.attach(MIMEText(html_body, "html"))
            with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT) as server:
                server.starttls()
                server.login(Config.SMTP_USER, Config.SMTP_PASS)
                server.sendmail(Config.SMTP_USER, to_list, msg.as_string())
            print(f"[Email] Sent '{subject}' to {to_list}")
        except Exception as e:
            print(f"[Email] Error sending: {e}")
    threading.Thread(target=_send, daemon=True).start()


def _send_whatsapp_async(to_list, message):
    def _send():
        if not Config.TWILIO_SID or not Config.TWILIO_TOKEN:
            print(f"[WhatsApp] Twilio not configured. Would send to {to_list}: {message[:80]}")
            return
        try:
            from twilio.rest import Client
            client = Client(Config.TWILIO_SID, Config.TWILIO_TOKEN)
            for phone in to_list:
                if not phone.startswith("whatsapp:"):
                    phone = f"whatsapp:{phone}"
                client.messages.create(
                    body=message,
                    from_=Config.TWILIO_WHATSAPP_FROM,
                    to=phone,
                )
            print(f"[WhatsApp] Sent to {to_list}")
        except Exception as e:
            print(f"[WhatsApp] Error sending: {e}")
    threading.Thread(target=_send, daemon=True).start()


def _duplicate_email_html(filename, existing_file, user_name, similarity=None, dashboard_url="http://localhost:5000"):
    sim_text = f"<p><strong>Similarity Score:</strong> {similarity:.0%}</p>" if similarity else ""
    return f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
  body {{ font-family: 'Segoe UI', sans-serif; background: #0a0c0f; color: #e2eaf5; margin: 0; padding: 0; }}
  .container {{ max-width: 600px; margin: 30px auto; background: #10141a; border-radius: 12px; overflow: hidden; border: 1px solid #1e2d3d; }}
  .header {{ background: linear-gradient(135deg, #ff4c6a 0%, #ff6b35 100%); padding: 30px; text-align: center; }}
  .header h1 {{ margin: 0; color: #fff; font-size: 24px; letter-spacing: 0.05em; }}
  .header p {{ margin: 8px 0 0; color: rgba(255,255,255,0.85); font-size: 14px; }}
  .body {{ padding: 30px; }}
  .alert-box {{ background: rgba(255,76,106,0.1); border: 1px solid rgba(255,76,106,0.3); border-radius: 8px; padding: 20px; margin: 20px 0; }}
  .info-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #1e2d3d; font-size: 13px; }}
  .info-row:last-child {{ border-bottom: none; }}
  .label {{ color: #7a9ab8; }}
  .value {{ color: #e2eaf5; font-weight: 600; }}
  .btn {{ display: inline-block; background: #00d4ff; color: #000; text-decoration: none; padding: 12px 28px; border-radius: 8px; font-weight: 700; margin-top: 20px; }}
  .footer {{ background: #161c26; padding: 16px 30px; font-size: 11px; color: #3d5266; text-align: center; }}
  .badge {{ display: inline-block; background: rgba(255,76,106,0.2); color: #ff4c6a; padding: 3px 10px; border-radius: 99px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>⚠️ Duplicate File Detected</h1>
    <p>DDAS — Data Download Duplication Alert System</p>
  </div>
  <div class="body">
    <span class="badge">Critical Alert</span>
    <div class="alert-box">
      <div class="info-row"><span class="label">Uploaded File</span><span class="value">{filename}</span></div>
      <div class="info-row"><span class="label">Matches Existing</span><span class="value">{existing_file}</span></div>
      <div class="info-row"><span class="label">Uploaded By</span><span class="value">{user_name}</span></div>
      {f'<div class="info-row"><span class="label">Similarity</span><span class="value">{similarity:.0%}</span></div>' if similarity else ''}
    </div>
    <p style="color:#7a9ab8;font-size:13px;line-height:1.6;">
      A duplicate file upload was blocked by the DDAS system. The uploaded file matches an existing dataset in the repository.
      Review the alert in your dashboard for more details.
    </p>
    <a href="{dashboard_url}/alerts" class="btn">View in Dashboard →</a>
  </div>
  <div class="footer">DDAS Automated Alert · <a href="{dashboard_url}" style="color:#00d4ff">Open Dashboard</a></div>
</div>
</body>
</html>
"""


def send_duplicate_alert(
    to_emails: list,
    to_phones: list,
    filename: str,
    existing_file: str,
    user_name: str,
    similarity: Optional[float] = None,
    dashboard_url: str = "http://localhost:5000",
):
    """Send email + WhatsApp alerts for duplicate detection."""
    if to_emails:
        html = _duplicate_email_html(filename, existing_file, user_name, similarity, dashboard_url)
        _send_email_async(
            to_emails,
            f"🚨 DDAS Alert: Duplicate file detected — {filename}",
            html,
        )

    if to_phones:
        sim_text = f" (Similarity: {similarity:.0%})" if similarity else ""
        msg = (
            f"🚨 *DDAS Duplicate Alert*\n\n"
            f"📁 File: *{filename}*\n"
            f"🔁 Matches: *{existing_file}*{sim_text}\n"
            f"👤 Uploaded by: *{user_name}*\n\n"
            f"View dashboard: {dashboard_url}"
        )
        _send_whatsapp_async(to_phones, msg)


def send_test_notification(email: str = None, phone: str = None) -> dict:
    results = {}
    if email:
        html = _duplicate_email_html("test_file.csv", "original_data.csv", "TestUser", 0.95)
        _send_email_async([email], "DDAS Test Notification", html)
        results["email"] = "queued"
    if phone:
        _send_whatsapp_async([phone], "✅ DDAS Test: WhatsApp notifications are working!")
        results["whatsapp"] = "queued"
    return results
