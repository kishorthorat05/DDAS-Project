"""Security utilities for DDAS."""
import hashlib, hmac, html, os, re, time
from collections import defaultdict
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable

import jwt
from flask import request, jsonify, g
from werkzeug.security import generate_password_hash, check_password_hash
from config.settings import get_config

Config = get_config()

def create_access_token(payload: dict) -> str:
    now = int(time.time())
    data = {**payload, "iat": now, "exp": now + int(Config.JWT_ACCESS_TOKEN_EXPIRES.total_seconds()), "type": "access"}
    return jwt.encode(data, Config.JWT_SECRET, algorithm=Config.JWT_ALGORITHM)

def create_refresh_token(user_id: str) -> str:
    now = int(time.time())
    data = {"sub": user_id, "iat": now, "exp": now + int(Config.JWT_REFRESH_TOKEN_EXPIRES.total_seconds()), "type": "refresh"}
    return jwt.encode(data, Config.JWT_SECRET, algorithm=Config.JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    return jwt.decode(token, Config.JWT_SECRET, algorithms=[Config.JWT_ALGORITHM])

def jwt_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        g.current_user = None
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            try:
                g.current_user = decode_token(auth[7:])
            except jwt.ExpiredSignatureError:
                return jsonify({"error": "Token expired", "code": "TOKEN_EXPIRED"}), 401
            except jwt.InvalidTokenError:
                return jsonify({"error": "Invalid token", "code": "TOKEN_INVALID"}), 401
        return f(*args, **kwargs)
    return wrapper

def require_auth(f):
    @wraps(f)
    @jwt_required
    def wrapper(*args, **kwargs):
        if g.current_user is None:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return wrapper

def require_role(*roles):
    def decorator(f):
        @wraps(f)
        @require_auth
        def wrapper(*args, **kwargs):
            if g.current_user.get("role", "viewer") not in roles:
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator

def hash_password(plain: str) -> str:
    return generate_password_hash(plain, method="pbkdf2:sha256:600000")

def verify_password(plain: str, hashed: str) -> bool:
    return check_password_hash(hashed, plain)

def hash_file(file_path, algorithm=None) -> str:
    algo = algorithm or Config.HASH_ALGORITHM
    h = hashlib.new(algo)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(Config.HASH_CHUNK_SIZE), b""):
            h.update(chunk)
    return h.hexdigest()

def hash_md5(file_path) -> str:
    h = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(Config.HASH_CHUNK_SIZE), b""):
            h.update(chunk)
    return h.hexdigest()

def hash_bytes(data: bytes, algorithm=None) -> str:
    return hashlib.new(algorithm or Config.HASH_ALGORITHM, data).hexdigest()

def compute_fuzzy_hash(file_path) -> str:
    """Simplified similarity fingerprint using content sampling."""
    try:
        path = Path(file_path)
        size = path.stat().st_size
        if size == 0:
            return "empty"
        h = hashlib.md5()
        with open(file_path, "rb") as f:
            # Sample start, middle, end
            h.update(f.read(4096))
            if size > 8192:
                f.seek(size // 2)
                h.update(f.read(4096))
            if size > 4096:
                f.seek(max(0, size - 4096))
                h.update(f.read(4096))
        # Include size bucket
        size_bucket = (size // (1024 * 100)) * 100  # 100KB buckets
        h.update(str(size_bucket).encode())
        return h.hexdigest()[:16]
    except Exception:
        return ""

def similarity_score(hash1: str, hash2: str) -> float:
    """Simple hamming similarity between two hex hashes."""
    if not hash1 or not hash2:
        return 0.0
    min_len = min(len(hash1), len(hash2))
    if min_len == 0:
        return 0.0
    matches = sum(a == b for a, b in zip(hash1[:min_len], hash2[:min_len]))
    return matches / min_len

def is_allowed_extension(filename: str) -> bool:
    ext = Path(filename).suffix.lstrip(".").lower()
    return ext in Config.ALLOWED_EXTENSIONS

def sanitize_filename(filename: str) -> str:
    name = Path(filename).name
    name = re.sub(r"[^\w\s.\-]", "_", name)
    return name.strip(". ") or "upload"

def sanitize_str(value, max_length=500) -> str:
    if not isinstance(value, str):
        value = str(value) if value is not None else ""
    return html.escape(value.strip())[:max_length]

def sanitize_search_query(query: str) -> str:
    return re.sub(r"[%;\"'\\]", "", query.strip())[:200]

class RateLimiter:
    def __init__(self):
        self._store = defaultdict(list)
    def is_allowed(self, key, max_requests, window_seconds):
        now = time.time()
        cutoff = now - window_seconds
        self._store[key] = [t for t in self._store[key] if t > cutoff]
        if len(self._store[key]) >= max_requests:
            return False
        self._store[key].append(now)
        return True

_rate_limiter = RateLimiter()

def rate_limit(max_requests=30, window_seconds=60, key_fn=None):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
            key = key_fn(request) if key_fn else f"{f.__name__}:{ip}"
            if not _rate_limiter.is_allowed(key, max_requests, window_seconds):
                return jsonify({"error": "Rate limit exceeded.", "code": "RATE_LIMITED"}), 429
            return f(*args, **kwargs)
        return wrapper
    return decorator

_SAFE_URL_PATTERN = re.compile(
    r'^https?://(?!(?:localhost|127\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.))[^\s<>"{}|\\^`\[\]]+$',
    re.IGNORECASE,
)

def is_safe_url(url: str) -> bool:
    return bool(_SAFE_URL_PATTERN.match(url.strip()))
