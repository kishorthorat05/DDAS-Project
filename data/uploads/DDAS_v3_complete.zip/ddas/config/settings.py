"""DDAS Configuration"""
import os
from pathlib import Path
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

def env_str(name, default=""):
    return os.getenv(name, default)

class Config:
    BASE_DIR = BASE_DIR
    SECRET_KEY = env_str("SECRET_KEY", "ddas-secret-key-change-in-production")
    JWT_SECRET = env_str("JWT_SECRET", "ddas-jwt-secret-change-in-production")
    JWT_ALGORITHM = "HS256"
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=8)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
    CORS_ORIGINS = ["http://localhost:5000", "http://127.0.0.1:5000"]
    DATABASE_URL = env_str("DATABASE_URL", f"sqlite:///{BASE_DIR / 'data' / 'ddas.db'}")
    UPLOAD_FOLDER = BASE_DIR / "data" / "uploads"
    MAX_CONTENT_LENGTH = 500 * 1024 * 1024
    ALLOWED_EXTENSIONS = {
        "csv","tsv","xlsx","xls","json","xml","txt","pdf","zip","tar","gz",
        "jpg","jpeg","png","gif","bmp","webp","nc","h5","hdf5","geojson","shp","bin",
    }
    MONITORED_DIR = env_str("MONITORED_DIR", str(BASE_DIR / "data" / "monitored"))
    SCAN_INTERVAL_SECONDS = int(env_str("SCAN_INTERVAL", "5"))
    GEMINI_API_KEY = env_str("GEMINI_API_KEY", env_str("GOOGLE_API_KEY", ""))
    GEMINI_MODEL = env_str("GEMINI_MODEL", "gemini-2.0-flash")
    AI_MAX_TOKENS = int(env_str("AI_MAX_TOKENS", "512"))
    HASH_ALGORITHM = "sha256"
    HASH_CHUNK_SIZE = 65536
    # Email settings
    SMTP_HOST = env_str("SMTP_HOST", "smtp.gmail.com")
    SMTP_PORT = int(env_str("SMTP_PORT", "587"))
    SMTP_USER = env_str("SMTP_USER", "")
    SMTP_PASS = env_str("SMTP_PASS", "")
    ALERT_EMAIL_FROM = env_str("ALERT_EMAIL_FROM", "ddas@system.local")
    # WhatsApp / Twilio
    TWILIO_SID = env_str("TWILIO_SID", "")
    TWILIO_TOKEN = env_str("TWILIO_TOKEN", "")
    TWILIO_WHATSAPP_FROM = env_str("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")

    @classmethod
    def init_dirs(cls):
        cls.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
        (cls.BASE_DIR / "data").mkdir(parents=True, exist_ok=True)
        Path(cls.MONITORED_DIR).mkdir(parents=True, exist_ok=True)

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False

_MAP = {"development": DevelopmentConfig, "production": ProductionConfig}

def get_config():
    return _MAP.get(os.getenv("FLASK_ENV", "development"), DevelopmentConfig)
