"""
API blueprints for DDAS.
All endpoints return JSON. Auth via JWT Bearer token.
"""
import os
import uuid
from pathlib import Path

import requests
from flask import Blueprint, g, jsonify, request

from app.services.ai_service import chat as ai_chat, get_file_insights, is_api_configured
from app.services.dataset_service import (
    AlertService, DatasetService, HistoryService, ScanLogService
)
from app.services.monitor_service import manual_scan, monitor_status, start_monitor, stop_monitor
from app.utils.security import (
    hash_file, hash_bytes,
    is_allowed_extension, is_safe_url,
    jwt_required, rate_limit, require_auth, require_role,
    sanitize_filename, sanitize_search_query, sanitize_str,
    hash_password, verify_password, create_access_token, create_refresh_token,
)
from app.models.database import get_db, row_to_dict
from config.settings import get_config

Config = get_config()

# ─────────────────────────── Blueprints ──────────────────────────────────────

auth_bp   = Blueprint("auth",    __name__, url_prefix="/api/auth")
data_bp   = Blueprint("data",    __name__, url_prefix="/api")
upload_bp = Blueprint("upload",  __name__, url_prefix="/api")
alert_bp  = Blueprint("alerts",  __name__, url_prefix="/api")
monitor_bp= Blueprint("monitor", __name__, url_prefix="/api")
ai_bp     = Blueprint("ai",      __name__, url_prefix="/api/ai")

# ─────────────────────────── Helpers ─────────────────────────────────────────

def _ok(data: dict | list | None = None, **kwargs) -> tuple:
    payload = {"success": True}
    if data is not None:
        payload["data"] = data
    payload.update(kwargs)
    return jsonify(payload), 200


def _created(data: dict | None = None, **kwargs) -> tuple:
    payload = {"success": True}
    if data is not None:
        payload["data"] = data
    payload.update(kwargs)
    return jsonify(payload), 201


def _err(message: str, code: int = 400, error_code: str = "") -> tuple:
    return jsonify({"success": False, "error": message, "code": error_code or "ERROR"}), code


def _get_ip() -> str:
    return request.headers.get("X-Forwarded-For", request.remote_addr or "")


# ═════════════════════════════════════════════════════════════════════════════
# AUTH
# ═════════════════════════════════════════════════════════════════════════════

@auth_bp.post("/register")
@rate_limit(max_requests=5, window_seconds=3600)
def register():
    body = request.get_json(silent=True) or {}
    username = sanitize_str(body.get("username", ""), 50)
    password = body.get("password", "")
    email = sanitize_str(body.get("email", ""), 200)

    if not username or len(username) < 3:
        return _err("Username must be at least 3 characters.")
    if len(password) < 8:
        return _err("Password must be at least 8 characters.")

    pw_hash = hash_password(password)
    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                (username, email or None, pw_hash),
            )
            user = row_to_dict(conn.execute(
                "SELECT id, username, email, role FROM users WHERE username = ?", (username,)
            ).fetchone())
    except Exception:
        return _err("Username already exists.", 409, "CONFLICT")

    token = create_access_token({"sub": user["id"], "username": user["username"], "role": user["role"]})
    return _created({"user": user, "access_token": token})


@auth_bp.post("/login")
@rate_limit(max_requests=10, window_seconds=300)
def login():
    body = request.get_json(silent=True) or {}
    username = sanitize_str(body.get("username", ""), 50)
    password = body.get("password", "")

    with get_db() as conn:
        user = row_to_dict(conn.execute(
            "SELECT * FROM users WHERE username = ? AND is_active = 1", (username,)
        ).fetchone())

    if not user or not verify_password(password, user["password_hash"]):
        return _err("Invalid credentials.", 401, "INVALID_CREDENTIALS")

    token = create_access_token({"sub": user["id"], "username": user["username"], "role": user["role"]})
    refresh = create_refresh_token(user["id"])
    safe_user = {k: v for k, v in user.items() if k != "password_hash"}
    return _ok({"user": safe_user, "access_token": token, "refresh_token": refresh})


@auth_bp.get("/me")
@require_auth
def me():
    uid = g.current_user.get("sub")
    with get_db() as conn:
        user = row_to_dict(conn.execute(
            "SELECT id, username, email, role, created_at FROM users WHERE id = ?", (uid,)
        ).fetchone())
    if not user:
        return _err("User not found.", 404)
    return _ok(user)


# ═════════════════════════════════════════════════════════════════════════════
# DATASETS
# ═════════════════════════════════════════════════════════════════════════════

@data_bp.get("/datasets")
@jwt_required
def get_datasets():
    limit  = min(int(request.args.get("limit", 100)), 500)
    offset = int(request.args.get("offset", 0))
    return _ok(DatasetService.get_all(limit, offset))


@data_bp.get("/datasets/<dataset_id>")
@jwt_required
def get_dataset(dataset_id: str):
    ds = DatasetService.get_by_id(dataset_id)
    if not ds:
        return _err("Dataset not found.", 404, "NOT_FOUND")
    history = HistoryService.get_for_dataset(dataset_id)
    return _ok({"dataset": ds, "history": history})


@data_bp.get("/datasets/search")
@jwt_required
def search_datasets():
    q = sanitize_search_query(request.args.get("q", ""))
    if not q:
        return _ok(DatasetService.get_all(limit=100))
    return _ok(DatasetService.search(q))


@data_bp.get("/datasets/stats")
@jwt_required
def dataset_stats():
    return _ok(DatasetService.stats())


@data_bp.post("/check-duplicate")
@jwt_required
@rate_limit(max_requests=100, window_seconds=60)
def check_duplicate():
    body = request.get_json(silent=True) or {}
    file_hash = sanitize_str(body.get("file_hash", ""), 128)
    if not file_hash:
        return _err("file_hash is required.")
    existing = DatasetService.get_by_hash(file_hash)
    if existing:
        return _ok({"exists": True, "dataset": existing})
    return _ok({"exists": False})


# ═════════════════════════════════════════════════════════════════════════════
# UPLOAD
# ═════════════════════════════════════════════════════════════════════════════

@upload_bp.post("/upload/file")
@jwt_required
@rate_limit(max_requests=20, window_seconds=3600)
def upload_file():
    if "file" not in request.files:
        return _err("No file provided.")

    file = request.files["file"]
    if not file.filename:
        return _err("Empty filename.")

    filename = sanitize_filename(file.filename)
    if not is_allowed_extension(filename):
        return _err(f"File type not allowed: {Path(filename).suffix}")

    user_name  = sanitize_str(request.form.get("user_name", "Anonymous"), 100)
    description= sanitize_str(request.form.get("description", ""), 500)
    period     = sanitize_str(request.form.get("period", ""), 100)
    spatial_domain = sanitize_str(request.form.get("spatial_domain", ""), 200)

    # Save to upload dir
    Config.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
    dest = Config.UPLOAD_FOLDER / filename
    # Avoid overwriting — append uuid if exists
    if dest.exists():
        stem = dest.stem
        dest = Config.UPLOAD_FOLDER / f"{stem}_{uuid.uuid4().hex[:8]}{dest.suffix}"

    file.save(str(dest))
    file_hash = hash_file(dest)
    file_size = dest.stat().st_size
    file_type = dest.suffix.lower()

    existing = DatasetService.get_by_hash(file_hash)
    if existing:
        HistoryService.log(
            dataset_id=existing["id"],
            user_name=user_name,
            file_name=filename,
            file_hash=file_hash,
            action="web_upload",
            status="duplicate_detected",
            ip_address=_get_ip(),
        )
        AlertService.create(
            title=f"Duplicate upload: {filename}",
            message=f"Uploaded file matches '{existing['file_name']}' already in repository.",
            file_name=filename,
            file_hash=file_hash,
            file_path=str(dest),
            existing_dataset_id=existing["id"],
        )
        dest.unlink(missing_ok=True)  # don't keep the dupe on disk
        return _ok({
            "is_duplicate": True,
            "existing_file": existing["file_name"],
            "dataset": existing,
        }, message="Duplicate detected — file already in repository.")

    ds = DatasetService.create(
        file_hash=file_hash, file_name=filename, file_size=file_size,
        file_path=str(dest), file_type=file_type, user_name=user_name,
        period=period or None, spatial_domain=spatial_domain or None,
        description=description or None,
    )
    HistoryService.log(
        dataset_id=ds["id"], user_name=user_name, file_name=filename,
        file_hash=file_hash, action="web_upload", status="success", ip_address=_get_ip(),
    )

    insights = get_file_insights(filename, file_size, file_type, description)
    return _created({"is_duplicate": False, "dataset": ds, "ai_insights": insights},
                    message="File uploaded successfully.")


@upload_bp.post("/upload/url")
@jwt_required
@rate_limit(max_requests=10, window_seconds=3600)
def upload_from_url():
    body = request.get_json(silent=True) or {}
    url  = sanitize_str(body.get("url", ""), 2000)
    user_name   = sanitize_str(body.get("user_name", "Anonymous"), 100)
    description = sanitize_str(body.get("description", ""), 500)

    if not url:
        return _err("URL is required.")
    if not is_safe_url(url):
        return _err("Invalid or unsafe URL. Private/loopback addresses are not allowed.", 400, "UNSAFE_URL")

    try:
        resp = requests.get(url, timeout=30, stream=True,
                            headers={"User-Agent": "DDAS/2.0"})
        resp.raise_for_status()
    except requests.RequestException as exc:
        return _err(f"Failed to download file: {exc}", 400, "DOWNLOAD_FAILED")

    # Derive filename
    from urllib.parse import urlparse
    url_path = urlparse(url).path
    filename = sanitize_filename(os.path.basename(url_path) or f"download_{uuid.uuid4().hex[:8]}")
    if not is_allowed_extension(filename):
        filename = filename + ".bin"

    Config.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
    dest = Config.UPLOAD_FOLDER / filename
    if dest.exists():
        dest = Config.UPLOAD_FOLDER / f"{dest.stem}_{uuid.uuid4().hex[:8]}{dest.suffix}"

    with open(dest, "wb") as fh:
        for chunk in resp.iter_content(chunk_size=65536):
            fh.write(chunk)

    file_hash = hash_file(dest)
    file_size = dest.stat().st_size
    file_type = dest.suffix.lower()

    existing = DatasetService.get_by_hash(file_hash)
    if existing:
        dest.unlink(missing_ok=True)
        return _ok({"is_duplicate": True, "existing_file": existing["file_name"], "dataset": existing},
                   message="Duplicate — file already in repository.")

    ds = DatasetService.create(
        file_hash=file_hash, file_name=filename, file_size=file_size,
        file_path=str(dest), file_type=file_type, user_name=user_name,
        description=description or None,
    )
    insights = get_file_insights(filename, file_size, file_type, description)
    return _created({"is_duplicate": False, "dataset": ds, "ai_insights": insights},
                    message="File downloaded and registered.")


# ═════════════════════════════════════════════════════════════════════════════
# ALERTS
# ═════════════════════════════════════════════════════════════════════════════

@alert_bp.get("/alerts")
@jwt_required
def get_alerts():
    unread_only = request.args.get("unread") == "1"
    limit = min(int(request.args.get("limit", 100)), 500)
    alerts = AlertService.get_all(unread_only=unread_only, limit=limit)
    count = AlertService.unread_count()
    return _ok({"alerts": alerts, "unread_count": count})


@alert_bp.patch("/alerts/<alert_id>/read")
@jwt_required
def mark_alert_read(alert_id: str):
    AlertService.mark_read(alert_id)
    return _ok(message="Alert marked as read.")


@alert_bp.post("/alerts/read-all")
@jwt_required
def mark_all_alerts_read():
    AlertService.mark_all_read()
    return _ok(message="All alerts marked as read.")


# ═════════════════════════════════════════════════════════════════════════════
# MONITOR
# ═════════════════════════════════════════════════════════════════════════════

@monitor_bp.post("/monitor/scan")
@jwt_required
@rate_limit(max_requests=5, window_seconds=60)
def trigger_scan():
    directory = sanitize_str(request.get_json(silent=True, force=True).get("directory", "") if request.data else "", 500)
    result = manual_scan(directory or None)
    return _ok(result)


@monitor_bp.get("/monitor/status")
@jwt_required
def get_monitor_status():
    return _ok(monitor_status())


@monitor_bp.post("/monitor/start")
@require_role("admin", "operator")
def start_monitor_route():
    started = start_monitor()
    return _ok({"started": started})


@monitor_bp.post("/monitor/stop")
@require_role("admin")
def stop_monitor_route():
    stop_monitor()
    return _ok({"stopped": True})


@monitor_bp.get("/scan-logs")
@jwt_required
def get_scan_logs():
    limit = min(int(request.args.get("limit", 100)), 500)
    return _ok(ScanLogService.get_recent(limit))


@monitor_bp.get("/history")
@jwt_required
def get_history():
    limit = min(int(request.args.get("limit", 100)), 500)
    return _ok(HistoryService.get_recent(limit))


# ═════════════════════════════════════════════════════════════════════════════
# AI
# ═════════════════════════════════════════════════════════════════════════════

# In-memory session store (swap for Redis in production)
_chat_sessions: dict[str, list[dict]] = {}
_MAX_HISTORY = 20


@ai_bp.post("/chat")
@jwt_required
@rate_limit(max_requests=60, window_seconds=3600)
def chat_endpoint():
    body = request.get_json(silent=True) or {}
    message = sanitize_str(body.get("message", ""), 2000)
    session_id = sanitize_str(body.get("session_id", "default"), 64)
    context = sanitize_str(body.get("context", ""), 1000)

    if not message:
        return _err("message is required.")

    history = _chat_sessions.get(session_id, [])
    reply = ai_chat(message, history, context)

    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": reply})
    _chat_sessions[session_id] = history[-_MAX_HISTORY:]

    return _ok({"reply": reply, "session_id": session_id})


@ai_bp.post("/chat/clear")
@jwt_required
def clear_chat():
    body = request.get_json(silent=True) or {}
    session_id = sanitize_str(body.get("session_id", "default"), 64)
    _chat_sessions.pop(session_id, None)
    return _ok(message="Chat history cleared.")


@ai_bp.get("/status")
def ai_status():
    return _ok({
        "api_configured": is_api_configured(),
        "model": Config.CLAUDE_MODEL,
        "provider": "Anthropic Claude",
    })
