"""
Database models and schema management for DDAS.
Uses sqlite3 directly — no ORM overhead, keeps it lightweight.
"""
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

from config.settings import get_config

Config = get_config()

# Resolve path from DATABASE_URL (supports sqlite:///path)
_db_url: str = Config.DATABASE_URL
if _db_url.startswith("sqlite:///"):
    DB_PATH = Path(_db_url[len("sqlite:///"):])
else:
    DB_PATH = Path(_db_url)

DB_PATH.parent.mkdir(parents=True, exist_ok=True)


# ─────────────────────────── connection helper ────────────────────────────────

@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """Thread-safe SQLite connection with WAL mode + foreign keys enabled."""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


def rows_to_list(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(r) for r in rows]


# ─────────────────────────── schema ──────────────────────────────────────────

SCHEMA_SQL = """
-- Users (optional auth)
CREATE TABLE IF NOT EXISTS users (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    username    TEXT UNIQUE NOT NULL,
    email       TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'viewer',   -- admin | operator | viewer
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Registered datasets
CREATE TABLE IF NOT EXISTS datasets (
    id                  TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    file_hash           TEXT NOT NULL UNIQUE,
    file_name           TEXT NOT NULL,
    file_size           INTEGER NOT NULL DEFAULT 0,
    file_path           TEXT NOT NULL,
    file_type           TEXT,
    user_name           TEXT NOT NULL DEFAULT 'System',
    period              TEXT,
    spatial_domain      TEXT,
    attributes          TEXT,   -- JSON blob
    description         TEXT,
    download_timestamp  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_datasets_hash      ON datasets(file_hash);
CREATE INDEX IF NOT EXISTS idx_datasets_user      ON datasets(user_name);
CREATE INDEX IF NOT EXISTS idx_datasets_file_type ON datasets(file_type);
CREATE INDEX IF NOT EXISTS idx_datasets_created   ON datasets(created_at DESC);

-- Download / scan history
CREATE TABLE IF NOT EXISTS download_history (
    id                  TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    dataset_id          TEXT REFERENCES datasets(id) ON DELETE SET NULL,
    user_name           TEXT NOT NULL DEFAULT 'System',
    file_name           TEXT,
    file_hash           TEXT,
    attempt_timestamp   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    action              TEXT NOT NULL DEFAULT 'download_attempt',
    status              TEXT NOT NULL DEFAULT 'success',   -- success | duplicate_detected | error
    ip_address          TEXT,
    notes               TEXT
);

CREATE INDEX IF NOT EXISTS idx_history_dataset    ON download_history(dataset_id);
CREATE INDEX IF NOT EXISTS idx_history_status     ON download_history(status);
CREATE INDEX IF NOT EXISTS idx_history_timestamp  ON download_history(attempt_timestamp DESC);

-- Alerts
CREATE TABLE IF NOT EXISTS alerts (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    alert_type      TEXT NOT NULL DEFAULT 'duplicate',
    severity        TEXT NOT NULL DEFAULT 'warning',   -- info | warning | critical
    title           TEXT NOT NULL,
    message         TEXT NOT NULL,
    file_name       TEXT,
    file_hash       TEXT,
    file_path       TEXT,
    existing_dataset_id TEXT REFERENCES datasets(id) ON DELETE SET NULL,
    is_read         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_alerts_read    ON alerts(is_read);
CREATE INDEX IF NOT EXISTS idx_alerts_type    ON alerts(alert_type);
CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at DESC);

-- Scan logs
CREATE TABLE IF NOT EXISTS scan_logs (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    file_path   TEXT NOT NULL,
    file_name   TEXT,
    file_size   INTEGER,
    file_hash   TEXT,
    is_duplicate INTEGER NOT NULL DEFAULT 0,
    scanned_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    error       TEXT
);

CREATE INDEX IF NOT EXISTS idx_scan_logs_scanned ON scan_logs(scanned_at DESC);
"""


def init_db() -> None:
    """Create all tables if they don't exist. Safe to call multiple times."""
    with get_db() as conn:
        conn.executescript(SCHEMA_SQL)
    print(f"[DB] Initialized at {DB_PATH}")
