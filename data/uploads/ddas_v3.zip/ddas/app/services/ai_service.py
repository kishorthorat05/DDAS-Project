"""
AI service powered by Anthropic Claude.
Provides: file insight generation and conversational chat.
Falls back to rule-based responses when API key is absent.
"""
import json
import os
from pathlib import Path
from typing import Any

import anthropic

from config.settings import get_config

Config = get_config()

# ─────────────────────────── Client ──────────────────────────────────────────

def _get_client() -> anthropic.Anthropic | None:
    key = Config.ANTHROPIC_API_KEY.strip()
    if not key or key.startswith("sk-ant-") is False and len(key) < 20:
        return None
    try:
        return anthropic.Anthropic(api_key=key)
    except Exception:
        return None


def is_api_configured() -> bool:
    key = Config.ANTHROPIC_API_KEY.strip()
    return bool(key) and len(key) >= 20


# ─────────────────────────── System prompts ──────────────────────────────────

_CHAT_SYSTEM = """You are DDAS Copilot, an expert AI assistant for the Data Download Duplication Alert System.

Your responsibilities:
1. Help users operate DDAS: uploading files, scanning directories, reading alerts, browsing the repository.
2. Explain duplicate detection (SHA-256 hash comparison) and best data management practices.
3. Provide actionable, concise recommendations — not generic theory.
4. If the user asks about file formats, data analysis, or tools, answer helpfully with practical steps.

Guidelines:
- Respond in a professional but friendly tone.
- Use short bullet lists when listing steps or options.
- Prioritize context provided about recent uploads or repository state.
- Keep replies focused and under 400 words unless a detailed explanation is clearly needed.
- If an OpenAI API is mentioned, note that DDAS now uses Anthropic Claude."""

_INSIGHT_SYSTEM = """You are a data file analyst. Given metadata about an uploaded file, produce a concise,
structured analysis covering:
1. What the file likely contains (inferred from name, type, size)
2. Recommended tools for processing it
3. Key analysis steps
4. Best practices for this file type
5. One concrete next step

Keep the response under 350 words. Use markdown formatting with **bold** headers."""


# ─────────────────────────── File insights ───────────────────────────────────

def get_file_insights(
    file_name: str,
    file_size: int,
    file_type: str,
    description: str = "",
) -> str:
    """Return AI analysis of an uploaded file. Falls back to rule-based if no API."""
    if not is_api_configured():
        return _rule_based_insights(file_name, file_size, file_type, description)

    client = _get_client()
    if not client:
        return _rule_based_insights(file_name, file_size, file_type, description)

    size_mb = file_size / (1024 * 1024)
    prompt = (
        f"File: **{file_name}**\n"
        f"Size: {size_mb:.2f} MB ({file_size:,} bytes)\n"
        f"Type: `{file_type}`\n"
        f"Description: {description or 'Not provided'}\n\n"
        "Please provide a structured analysis of this file."
    )

    try:
        resp = client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=Config.AI_MAX_TOKENS,
            system=_INSIGHT_SYSTEM,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text
    except anthropic.AuthenticationError:
        return "⚠️ Anthropic API key is invalid. Check your `ANTHROPIC_API_KEY` env variable.\n\n" + \
               _rule_based_insights(file_name, file_size, file_type, description)
    except Exception as exc:
        return f"⚠️ AI analysis unavailable ({exc}).\n\n" + \
               _rule_based_insights(file_name, file_size, file_type, description)


# ─────────────────────────── Chat ────────────────────────────────────────────

def chat(
    message: str,
    history: list[dict[str, str]],
    context: str = "",
) -> str:
    """
    Send a message to Claude with full conversation history.
    history: list of {"role": "user"|"assistant", "content": "..."}
    Returns assistant reply string.
    """
    if not is_api_configured():
        return _rule_based_chat(message)

    client = _get_client()
    if not client:
        return _rule_based_chat(message)

    system = _CHAT_SYSTEM
    if context:
        system += f"\n\nCurrent context from the UI:\n{context}"

    # Build messages — Claude requires alternating user/assistant
    messages = []
    for turn in history[-18:]:  # keep last 18 turns (9 exchanges)
        if turn.get("role") in ("user", "assistant") and turn.get("content"):
            messages.append({"role": turn["role"], "content": turn["content"]})

    messages.append({"role": "user", "content": message})

    try:
        resp = client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=Config.AI_MAX_TOKENS,
            system=system,
            messages=messages,
        )
        return resp.content[0].text
    except anthropic.AuthenticationError:
        return "⚠️ API key invalid. Please set `ANTHROPIC_API_KEY` in your `.env` file."
    except anthropic.RateLimitError:
        return "⚠️ Rate limit hit. Please wait a moment and try again."
    except Exception as exc:
        return _rule_based_chat(message)


# ─────────────────────────── Rule-based fallback ─────────────────────────────

def _rule_based_insights(name: str, size: int, ftype: str, desc: str) -> str:
    size_mb = size / (1024 * 1024)
    ext = ftype.lstrip(".").lower()

    type_info = {
        "csv": ("📊 Tabular / spreadsheet data", "Python Pandas, Excel, DuckDB", "Load with `pd.read_csv()`, check dtypes, handle NaNs"),
        "tsv": ("📊 Tab-separated tabular data", "Python Pandas, Excel", "Load with `pd.read_csv(sep='\\t')`, inspect columns"),
        "json": ("🔗 Structured nested data", "Python json / Pandas, Node.js, MongoDB", "Parse with `json.load()`, flatten with `pd.json_normalize()`"),
        "xlsx": ("📈 Excel workbook (multi-sheet)", "Python openpyxl / Pandas, Excel", "Use `pd.ExcelFile()` to inspect sheets, then `pd.read_excel()`"),
        "xls": ("📈 Legacy Excel format", "Python xlrd / Pandas, LibreOffice", "Convert to xlsx first for modern tooling"),
        "pdf": ("📄 Fixed-layout document", "pdfplumber, PyMuPDF, Adobe", "Extract text with `pdfplumber.open()`"),
        "jpg": ("🖼️ JPEG image", "PIL/Pillow, OpenCV, ImageMagick", "Open with `Image.open()`, check resolution & mode"),
        "png": ("🖼️ PNG image (lossless)", "PIL/Pillow, OpenCV", "Check transparency channel, resize with `img.resize()`"),
        "nc": ("🌍 NetCDF geoscientific data", "xarray, netCDF4, CDO", "Load with `xr.open_dataset()`, check dimensions & variables"),
        "geojson": ("🗺️ GeoJSON spatial data", "GeoPandas, QGIS, Leaflet.js", "Load with `geopandas.read_file()`, visualize with folium"),
    }

    category, tools, steps = type_info.get(ext, (
        f"📂 Binary/unknown file (`{ftype}`)",
        "File-type specific tools",
        "Inspect with `file` command, check magic bytes",
    ))

    return (
        f"## {category}\n\n"
        f"**File:** `{name}` | **Size:** {size_mb:.2f} MB\n\n"
        f"**Recommended tools:** {tools}\n\n"
        f"**Key steps:** {steps}\n\n"
        f"{'**Description:** ' + desc + chr(10) + chr(10) if desc else ''}"
        f"**Best practices:**\n"
        f"- Verify file integrity after upload\n"
        f"- Check for missing values before analysis\n"
        f"- Keep a backup of the original file\n"
        f"- Document data sources and transformations\n\n"
        f"*Set `ANTHROPIC_API_KEY` in `.env` for deeper AI-powered analysis.*"
    )


def _rule_based_chat(message: str) -> str:
    m = message.lower()
    if any(w in m for w in ("hello", "hi ", "hey", "start")):
        return (
            "👋 Hi! I'm DDAS Copilot.\n\n"
            "I can help you with:\n"
            "- Uploading and analyzing files\n"
            "- Understanding duplicate detection\n"
            "- Searching the dataset repository\n"
            "- Explaining file formats and analysis approaches\n\n"
            "Set `ANTHROPIC_API_KEY` in your `.env` for full AI-powered responses!"
        )
    if any(w in m for w in ("duplicate", "copy", "same file", "hash")):
        return (
            "**How Duplicate Detection Works**\n\n"
            "DDAS computes a **SHA-256 hash** (a unique fingerprint) for every file.\n"
            "When a new file arrives:\n"
            "1. Its hash is computed\n"
            "2. The hash is looked up in the repository\n"
            "3. If a match is found → duplicate alert is raised\n"
            "4. If no match → the file is registered as new\n\n"
            "SHA-256 is collision-resistant, meaning two different files will never produce the same hash."
        )
    if any(w in m for w in ("upload", "add file", "register")):
        return (
            "**Uploading a File**\n\n"
            "1. Go to the **Upload** tab in the dashboard\n"
            "2. Choose a local file **or** paste a URL\n"
            "3. Optionally add your name, description, spatial domain, period\n"
            "4. Click **Upload**\n\n"
            "The system will:\n"
            "- Compute the SHA-256 hash\n"
            "- Check for duplicates\n"
            "- Register the file in the repository\n"
            "- Generate an AI insight summary"
        )
    return (
        "I'm DDAS Copilot running in **demo mode** (no API key configured).\n\n"
        "I can answer questions about:\n"
        "- Duplicate detection & file hashing\n"
        "- How to upload files or use the repository\n"
        "- File format analysis\n\n"
        "Set `ANTHROPIC_API_KEY=sk-ant-...` in your `.env` file to unlock full AI responses."
    )
