"""
DatasetService — all database operations for datasets, history, alerts, scan_logs.
Returns plain dicts; no ORM objects leaked to the API layer.
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.models.database import get_db, row_to_dict, rows_to_list


# ─────────────────────────── Dataset CRUD ────────────────────────────────────

class DatasetService:

    @staticmethod
    def get_all(limit: int = 200, offset: int = 0) -> list[dict]:
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM datasets ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def get_by_id(dataset_id: str) -> dict | None:
        with get_db() as conn:
            row = conn.execute("SELECT * FROM datasets WHERE id = ?", (dataset_id,)).fetchone()
        return row_to_dict(row)

    @staticmethod
    def get_by_hash(file_hash: str) -> dict | None:
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM datasets WHERE file_hash = ?", (file_hash,)
            ).fetchone()
        return row_to_dict(row)

    @staticmethod
    def exists(file_hash: str) -> bool:
        with get_db() as conn:
            row = conn.execute(
                "SELECT 1 FROM datasets WHERE file_hash = ? LIMIT 1", (file_hash,)
            ).fetchone()
        return row is not None

    @staticmethod
    def create(
        file_hash: str,
        file_name: str,
        file_size: int,
        file_path: str,
        file_type: str = "",
        user_name: str = "System",
        period: str | None = None,
        spatial_domain: str | None = None,
        attributes: dict | None = None,
        description: str | None = None,
    ) -> dict:
        attrs_json = json.dumps(attributes) if attributes else None
        with get_db() as conn:
            conn.execute(
                """INSERT INTO datasets
                   (file_hash, file_name, file_size, file_path, file_type,
                    user_name, period, spatial_domain, attributes, description)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (file_hash, file_name, file_size, file_path, file_type,
                 user_name, period, spatial_domain, attrs_json, description),
            )
            row = conn.execute(
                "SELECT * FROM datasets WHERE file_hash = ?", (file_hash,)
            ).fetchone()
        return row_to_dict(row)  # type: ignore[return-value]

    @staticmethod
    def search(query: str, limit: int = 100) -> list[dict]:
        pattern = f"%{query}%"
        with get_db() as conn:
            rows = conn.execute(
                """SELECT * FROM datasets
                   WHERE file_name LIKE ?
                      OR spatial_domain LIKE ?
                      OR period LIKE ?
                      OR description LIKE ?
                      OR file_type LIKE ?
                   ORDER BY created_at DESC
                   LIMIT ?""",
                (pattern, pattern, pattern, pattern, pattern, limit),
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def stats() -> dict[str, Any]:
        with get_db() as conn:
            total = conn.execute("SELECT COUNT(*) FROM datasets").fetchone()[0]
            total_size = conn.execute(
                "SELECT COALESCE(SUM(file_size), 0) FROM datasets"
            ).fetchone()[0]
            dup_count = conn.execute(
                "SELECT COUNT(*) FROM download_history WHERE status = 'duplicate_detected'"
            ).fetchone()[0]
            unique_domains = conn.execute(
                "SELECT COUNT(DISTINCT spatial_domain) FROM datasets WHERE spatial_domain IS NOT NULL AND spatial_domain != ''"
            ).fetchone()[0]
            file_types = conn.execute(
                """SELECT file_type, COUNT(*) as cnt FROM datasets
                   WHERE file_type IS NOT NULL AND file_type != ''
                   GROUP BY file_type ORDER BY cnt DESC LIMIT 10"""
            ).fetchall()
        return {
            "total_datasets": total,
            "total_size_bytes": total_size,
            "duplicate_prevention_count": dup_count,
            "unique_spatial_domains": unique_domains,
            "file_type_breakdown": rows_to_list(file_types),
        }


# ─────────────────────────── Download History ────────────────────────────────

class HistoryService:

    @staticmethod
    def log(
        dataset_id: str | None,
        user_name: str = "System",
        file_name: str = "",
        file_hash: str = "",
        action: str = "download_attempt",
        status: str = "success",
        ip_address: str = "",
        notes: str = "",
    ) -> None:
        with get_db() as conn:
            conn.execute(
                """INSERT INTO download_history
                   (dataset_id, user_name, file_name, file_hash, action, status, ip_address, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (dataset_id, user_name, file_name, file_hash,
                 action, status, ip_address, notes),
            )

    @staticmethod
    def get_for_dataset(dataset_id: str, limit: int = 50) -> list[dict]:
        with get_db() as conn:
            rows = conn.execute(
                """SELECT * FROM download_history
                   WHERE dataset_id = ?
                   ORDER BY attempt_timestamp DESC LIMIT ?""",
                (dataset_id, limit),
            ).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def get_recent(limit: int = 100) -> list[dict]:
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM download_history ORDER BY attempt_timestamp DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return rows_to_list(rows)


# ─────────────────────────── Alerts ──────────────────────────────────────────

class AlertService:

    @staticmethod
    def create(
        title: str,
        message: str,
        alert_type: str = "duplicate",
        severity: str = "warning",
        file_name: str = "",
        file_hash: str = "",
        file_path: str = "",
        existing_dataset_id: str | None = None,
    ) -> dict:
        with get_db() as conn:
            conn.execute(
                """INSERT INTO alerts
                   (alert_type, severity, title, message,
                    file_name, file_hash, file_path, existing_dataset_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (alert_type, severity, title, message,
                 file_name, file_hash, file_path, existing_dataset_id),
            )
            row = conn.execute(
                "SELECT * FROM alerts ORDER BY created_at DESC LIMIT 1"
            ).fetchone()
        return row_to_dict(row)  # type: ignore[return-value]

    @staticmethod
    def get_all(unread_only: bool = False, limit: int = 100) -> list[dict]:
        sql = "SELECT * FROM alerts"
        params: list[Any] = []
        if unread_only:
            sql += " WHERE is_read = 0"
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with get_db() as conn:
            rows = conn.execute(sql, params).fetchall()
        return rows_to_list(rows)

    @staticmethod
    def mark_read(alert_id: str) -> None:
        with get_db() as conn:
            conn.execute("UPDATE alerts SET is_read = 1 WHERE id = ?", (alert_id,))

    @staticmethod
    def mark_all_read() -> None:
        with get_db() as conn:
            conn.execute("UPDATE alerts SET is_read = 1")

    @staticmethod
    def unread_count() -> int:
        with get_db() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM alerts WHERE is_read = 0"
            ).fetchone()[0]


# ─────────────────────────── Scan Logs ───────────────────────────────────────

class ScanLogService:

    @staticmethod
    def log(
        file_path: str,
        file_name: str = "",
        file_size: int = 0,
        file_hash: str = "",
        is_duplicate: bool = False,
        error: str = "",
    ) -> None:
        with get_db() as conn:
            conn.execute(
                """INSERT INTO scan_logs
                   (file_path, file_name, file_size, file_hash, is_duplicate, error)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (file_path, file_name, file_size, file_hash,
                 1 if is_duplicate else 0, error or None),
            )

    @staticmethod
    def get_recent(limit: int = 100) -> list[dict]:
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM scan_logs ORDER BY scanned_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return rows_to_list(rows)
