# Filtered Datasets Export

Export Date: 2026-04-02T20:29:08.231814
Total Datasets: 32

## Filter Criteria Used
{}

## Columns
- id: Dataset ID
- file_hash: SHA-256 hash
- file_name: Original filename
- file_size: Size in bytes
- download_timestamp: When file was registered
- file_type: File extension
- is_duplicate: Whether this is a duplicate
- user_name: User who uploaded/registered it
