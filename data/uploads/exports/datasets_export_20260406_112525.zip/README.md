# Filtered Datasets Export

Export Date: 2026-04-06T11:25:25.995232
Total Datasets: 45

## Filter Criteria Used
{}

## Columns
- id: Dataset ID
- file_hash: SHA-256 hash
- file_name: Original filename
- file_size: Size in bytes
- download_timestamp: When file was registered
- file_type: File extension
- user_name: User who uploaded/registered it
