# DDAS Scan Export

This export contains scan results and duplicate detection data.

## Contents
- SCAN_REPORT.json: Summary of the scan including total files, duplicates found, and error count
- DUPLICATES_SUMMARY.json: List of duplicate file groups detected in the system

## Data Download Duplication Alert System (DDAS)
For more information, visit the DDAS dashboard.
